import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function DueDatePage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Due Date</CardTitle>
        <CardDescription>
          Manage your due dates.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p>Due date information will be displayed here.</p>
      </CardContent>
    </Card>
  );
}
