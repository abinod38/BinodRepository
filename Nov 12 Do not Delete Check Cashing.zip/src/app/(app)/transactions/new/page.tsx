
'use client';

import { useEffect, useState, useTransition, useRef, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Loader2, ScanLine, Save, AlertCircle, RefreshCw, Upload, Camera, Sparkles, X, Info, User, Phone, Lock, Building, MapPin, MessageSquare, Trash2, ArrowRight, DollarSign, Banknote, CreditCard, Landmark, Clock, CheckCircle } from 'lucide-react';
import Image from 'next/image';
import { useSearchParams, useRouter } from 'next/navigation';

import { processDocument, type ProcessDocumentOutput } from '@/ai/flows/process-document-flow';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { useFirestore, useUser, useCollection, useMemoFirebase, useDoc } from "@/firebase";
import { addDocumentNonBlocking, updateDocumentNonBlocking } from "@/firebase/non-blocking-updates";
import { collection, serverTimestamp, query, orderBy, doc, Timestamp } from "firebase/firestore";
import { format as formatDateFns, parse, isValid, parseISO } from 'date-fns';
import { CameraCapture } from '@/components/ui/camera-capture';
import { Switch } from '@/components/ui/switch';
import { ToastAction } from '@/components/ui/toast';
import { DatePicker } from '@/components/ui/date-picker';


const formSchema = z.object({
  checkDate: z.string().optional(),
  transactionDate: z.date().optional(),
  timeOfTransaction: z.string().optional(),
  checkNumber: z.string().optional(),
  customerName: z.string().optional(),
  customerAddress: z.string().optional(),
  customerPhone: z.string().optional(),
  customerSsn: z.string().optional(),
  checkIssuerName: z.string().optional(),
  checkIssuerAddress: z.string().optional(),
  checkIssuerPhone: z.string().optional(),
  idNumber: z.string().optional(),
  expirationDate: z.string().optional(),
  dob: z.string().optional(),
  comment: z.string().optional(),
  checkAmount: z.coerce.number().positive().optional(),
  feeType: z.string().optional(),
  customFee: z.coerce.number().nonnegative().optional(),
  transactionType: z.enum(["Standard", "Hold"]).default("Standard"),
  holdType: z.enum(["Full Hold", "Partial Hold", "Customer Buyback"]).default("Full Hold"),
  holdUntilDate: z.date().optional(),
  accountNumber: z.string().optional(),
  routingNumber: z.string().optional(),
  bankName: z.string().optional(),
  isSigned: z.boolean().optional(),
});

type FormData = z.infer<typeof formSchema>;

type VerifiableField = keyof Pick<
  FormData,
  | 'customerName'
  | 'customerAddress'
  | 'customerPhone'
  | 'customerSsn'
  | 'checkIssuerName'
  | 'checkIssuerAddress'
  | 'checkIssuerPhone'
  | 'idNumber'
  | 'expirationDate'
  | 'dob'
  | 'checkNumber'
  | 'accountNumber'
  | 'routingNumber'
  | 'bankName'
>;

export default function Home() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const editId = searchParams.get('edit');
  
  const [checkImage, setCheckImage] = useState<string | null>(null);
  const [idImage, setIdImage] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [isCheckCameraOpen, setIsCheckCameraOpen] = useState(false);
  const [isIdCameraOpen, setIsIdCameraOpen] = useState(false);
  const [captureConfirmation, setCaptureConfirmation] = useState<{title: string, description: string} | null>(null);
  const [checkAmountDisplay, setCheckAmountDisplay] = useState("");
  const [customFeeDisplay, setCustomFeeDisplay] = useState("0.00");
  const [extractedData, setExtractedData] = useState<ProcessDocumentOutput | null>(null);
  
  const checkUploadRef = useRef<HTMLInputElement>(null);
  const idUploadRef = useRef<HTMLInputElement>(null);

  const { toast } = useToast();
  const firestore = useFirestore();
  const { user } = useUser();
  const [isClient, setIsClient] = useState(false);

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);
  const { data: transactions } = useCollection<any>(transactionsQuery);

  const transactionToEditRef = useMemoFirebase(() => {
    if (!editId || !user || !firestore) return null;
    return doc(firestore, `users/${user.uid}/transactions`, editId);
  }, [editId, user, firestore]);

  const { data: transactionToEdit, isLoading: isEditLoading } = useDoc<any>(transactionToEditRef);

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      transactionType: "Standard",
      holdType: "Full Hold",
      feeType: "standard",
      checkDate: "",
      transactionDate: new Date(),
      timeOfTransaction: "",
      checkNumber: "",
      customerName: "",
      customerAddress: "",
      customerPhone: "",
      customerSsn: "",
      checkIssuerName: "",
      checkIssuerAddress: "",
      checkIssuerPhone: "",
      idNumber: "",
      expirationDate: "",
      dob: "",
      comment: "",
      checkAmount: undefined,
      customFee: 0,
      holdUntilDate: undefined,
      accountNumber: "",
      routingNumber: "",
      bankName: "",
      isSigned: false,
    },
  });

  const [dateForDisplay, setDateForDisplay] = useState('');
  
  useEffect(() => {
    if (transactionToEdit) {
      const values: Partial<FormData> = {};
      for (const key in formSchema.shape) {
        if (key in transactionToEdit) {
          const formKey = key as keyof FormData;
          const value = transactionToEdit[key];

          if ((formKey === 'holdUntilDate' || formKey === 'transactionDate') && value) {
            let parsedDate;
            if (value.seconds) { // Firestore Timestamp
              parsedDate = (value as Timestamp).toDate();
            } else if (typeof value === 'string') {
              parsedDate = parseISO(value);
            }
            if (parsedDate && isValid(parsedDate)) {
               values[formKey] = parsedDate;
            }
          } else if (formKey === 'checkDate' && value) {
              setDateForDisplay(value);
              values[formKey] = value;
          }
          else {
            (values as any)[formKey] = value;
          }
        }
      }
      
      form.reset(values);
      if (transactionToEdit.checkAmount) {
        setCheckAmountDisplay(Number(transactionToEdit.checkAmount).toFixed(2));
      } else {
        setCheckAmountDisplay("");
      }
      if (transactionToEdit.customFee) {
        setCustomFeeDisplay(Number(transactionToEdit.customFee).toFixed(2));
      } else {
        setCustomFeeDisplay("0.00");
      }
      
      if (transactionToEdit.checkImage) setCheckImage(transactionToEdit.checkImage);
      if (transactionToEdit.idImage) setIdImage(transactionToEdit.idImage);
    }
  }, [transactionToEdit, form]);
  
  const checkAmountValue = form.watch("checkAmount") || 0;
  const feeType = form.watch("feeType");
  const customFee = form.watch("customFee") || 0;
  const transactionType = form.watch("transactionType");
  
  const watchedFormValues = form.watch();

  const existingDataSets = useMemo(() => {
    if (!transactions) {
      const emptySets: Record<VerifiableField, Set<string>> = {
        customerName: new Set(), customerAddress: new Set(), customerPhone: new Set(), customerSsn: new Set(),
        checkIssuerName: new Set(), checkIssuerAddress: new Set(), checkIssuerPhone: new Set(),
        idNumber: new Set(), expirationDate: new Set(), dob: new Set(), checkNumber: new Set(),
        accountNumber: new Set(), routingNumber: new Set(), bankName: new Set(),
      };
      return emptySets;
    }

    return transactions.reduce((acc, t) => {
      (Object.keys(acc) as VerifiableField[]).forEach(key => {
        if (t[key]) {
          acc[key].add(String(t[key]).toLowerCase());
        }
      });
      return acc;
    }, {
        customerName: new Set<string>(),
        customerAddress: new Set<string>(),
        customerPhone: new Set<string>(),
        customerSsn: new Set<string>(),
        checkIssuerName: new Set<string>(),
        checkIssuerAddress: new Set<string>(),
        checkIssuerPhone: new Set<string>(),
        idNumber: new Set<string>(),
        expirationDate: new Set<string>(),
        dob: new Set<string>(),
        checkNumber: new Set<string>(),
        accountNumber: new Set<string>(),
        routingNumber: new Set<string>(),
        bankName: new Set<string>(),
    } as Record<VerifiableField, Set<string>>);
  }, [transactions]);


  const isVerified = (field: VerifiableField) => {
    const value = watchedFormValues[field];
    return !!value && existingDataSets[field].has(String(value).toLowerCase());
  };

  const { fee, netAmount } = useMemo(() => {
    const amount = checkAmountValue || 0;
    let cents = 0;
    if (amount > 0 && amount % 1 !== 0) {
      cents = parseFloat((amount % 1).toFixed(2));
    }

    let baseFee = 0;

    if (feeType === 'standard') {
        if (amount > 0) {
            baseFee = Math.ceil(amount / 100) * 2;
        }
    } else if (feeType === 'special') {
        baseFee = amount * 0.01;
    } else if (feeType === 'waived') {
        baseFee = 0;
    } else if (feeType === 'custom') {
        baseFee = customFee || 0;
    }
    
    const totalFee = baseFee + cents;
    const finalNetAmount = amount - totalFee;

    return { fee: totalFee, netAmount: finalNetAmount };
  }, [checkAmountValue, feeType, customFee]);

  const [appliedData, setAppliedData] = useState<Set<keyof FormData>>(new Set());

  useEffect(() => {
    setIsClient(true);
  }, []);
  
  useEffect(() => {
    if (!isClient) return;

    const interval = setInterval(() => {
      const now = new Date();
      if (!editId) {
        form.setValue('timeOfTransaction', now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }));
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isClient, form, editId]);


  const showConfirmation = (title: string, description: string) => {
    setCaptureConfirmation({ title, description });
  };
  
  useEffect(() => {
    if (captureConfirmation) {
      const timer = setTimeout(() => {
        setCaptureConfirmation(null);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [captureConfirmation]);

  const resetCapture = (type: 'check' | 'id' | 'full') => {
    setAppliedData(new Set());
    setExtractedData(null);
    
    if (type === 'check' || type === 'full') {
        setCheckImage(null);
    } 
    if (type === 'id' || type === 'full') {
        setIdImage(null);
    }
  };

  const handleImageInput = (event: React.ChangeEvent<HTMLInputElement>, setImage: (image: string | null) => void, type: 'check' | 'id') => {
    const file = event.target.files?.[0];
    if (file) {
      resetCapture(type);
      const reader = new FileReader();
      reader.onload = e => {
        setImage(e.target?.result as string);
        const fileName = type === 'check' ? 'check-camera.jpg' : 'id-camera.jpg';
        showConfirmation("Image Uploaded", `Saved as ${fileName}`);
      }
      reader.readAsDataURL(file);
    }
    event.target.value = '';
  };
  
  const handleIdCapture = (imageDataUrl: string) => {
    resetCapture('id');
    setIdImage(imageDataUrl);
    setIsIdCameraOpen(false);
    showConfirmation("Image Captured", "Saved as id-camera.jpg");
  }

  const handleCheckCapture = (imageDataUrl: string) => {
    resetCapture('check');
    setCheckImage(imageDataUrl);
    setIsCheckCameraOpen(false);
    showConfirmation("Image Captured", "Saved as check-camera.jpg");
  }

  const handleApplyData = (data: ProcessDocumentOutput | null) => {
    if (!data) return;
    
    const newAppliedFields = new Set<keyof FormData>();

    const mapping = {
      check_number: "checkNumber",
      check_issuer: "checkIssuerName",
      issuer_address: "checkIssuerAddress",
      amount: "checkAmount",
      routing_number: "routingNumber",
      account_number: "accountNumber",
      signature_present: "isSigned",
      check_date: "checkDate",
      bank_name: "bankName",
      customer_address: "customerAddress",
      dl_number: "idNumber",
      expiration_date: "expirationDate",
      dob: "dob"
    };

    const processAndSetField = (formKey: keyof FormData, value: any) => {
      let processedValue: any = value;
      if (value === "N/A") {
        processedValue = "";
      }

      if (formKey === 'checkAmount') {
        const numericValue = typeof processedValue === 'number' ? processedValue : parseFloat(String(processedValue).replace(/[^0-9.-]+/g,""));
        if (!isNaN(numericValue)) {
          processedValue = numericValue;
          setCheckAmountDisplay(numericValue.toFixed(2));
        } else {
          return; // Skip if not a valid number
        }
      } else if ((formKey === 'checkDate' || formKey === 'dob' || formKey === 'expirationDate') && typeof processedValue === 'string') {
          const parsedDate = parse(processedValue, 'MM/dd/yyyy', new Date());
          if (isValid(parsedDate)) {
            if (formKey === 'checkDate') {
              setDateForDisplay(formatDateFns(parsedDate, 'MMMM do, yyyy'));
              processedValue = formatDateFns(parsedDate, 'MMMM do, yyyy');
            } else {
               processedValue = formatDateFns(parsedDate, 'MM/dd/yyyy');
            }
          } else {
            const genericParsedDate = new Date(processedValue);
            if (isValid(genericParsedDate)) {
                if(formKey === 'checkDate') {
                  setDateForDisplay(formatDateFns(genericParsedDate, 'MMMM do, yyyy'));
                  processedValue = formatDateFns(genericParsedDate, 'MMMM do, yyyy');
                } else {
                  processedValue = formatDateFns(genericParsedDate, 'MM/dd/yyyy');
                }
            } else {
              processedValue = value;
            }
          }
      } else if (formKey === 'isSigned' && typeof processedValue === 'string') {
        processedValue = processedValue.toLowerCase() === 'yes';
      }
      
      form.setValue(formKey, processedValue || '', { shouldValidate: true });
      newAppliedFields.add(formKey);
    };

    if (data.extracted_data) {
      for (const [key, value] of Object.entries(data.extracted_data)) {
        const formKey = mapping[key as keyof typeof mapping] as keyof FormData;
        if (formKey) {
          processAndSetField(formKey, value);
        }
      }
    }
    
    if (data.validation_data) {
      const { first_name, middle_name, last_name, ...rest } = data.validation_data;
      const fullName = [first_name, middle_name, last_name].filter(name => name && name !== 'N/A').join(' ');
      if (fullName) {
        processAndSetField('customerName', fullName);
      }

      for (const [key, value] of Object.entries(rest)) {
        const formKey = mapping[key as keyof typeof mapping] as keyof FormData;
        if (formKey) {
          processAndSetField(formKey, value);
        }
      }
    }

    setAppliedData(newAppliedFields);
    setExtractedData(null); // Clear the extracted data card
    toast({
      variant: "success",
      title: "Data Applied",
      description: "The extracted information has been applied to the form.",
      duration: 2000,
      className: "bg-teal-600 border-transparent text-white",
    });
  }

  const handleExtract = () => {
    if (!checkImage) {
      toast({
        variant: "destructive",
        title: "Check Image Required",
        description: "Please upload or capture the check image before scanning.",
      });
      return;
    }
    setError(null);
    setExtractedData(null);
    setAppliedData(new Set()); // Clear highlights on new scan

    const { dismiss: dismissScanningToast } = toast({
      title: "Image Scanning",
      description: "The AI is processing the images. Please wait a moment...",
      variant: 'success',
    });

    startTransition(async () => {
      try {
        const result = await processDocument({
            checkImage: checkImage,
            idImage: idImage,
        });

        dismissScanningToast();
        setExtractedData(result);

      } catch (e: any) {
        dismissScanningToast();
        setError(e.message || 'An unknown error occurred.');
        toast({
            variant: 'destructive',
            title: 'Extraction Failed',
            description: e.message || 'Could not extract data. Please try again.',
        });
      }
    });
  };

  const onSubmit = (values: FormData) => {
    if (!user) {
      toast({
        variant: "destructive",
        title: "Authentication Error",
        description: "You must be logged in to confirm a transaction.",
      });
      return;
    }
    
    if (editId && transactionToEditRef) {
      const transactionDate = values.transactionDate || new Date();
      if (transactionToEdit?.timeOfTransaction) {
        const timeParts = transactionToEdit.timeOfTransaction.match(/(\d+):(\d+):(\d+)\s?(AM|PM)?/);
        if (timeParts) {
          let hours = parseInt(timeParts[1], 10);
          const minutes = parseInt(timeParts[2], 10);
          const seconds = parseInt(timeParts[3], 10);
          const ampm = timeParts[4];
          if (ampm === 'PM' && hours < 12) hours += 12;
          if (ampm === 'AM' && hours === 12) hours = 0;
          transactionDate.setHours(hours, minutes, seconds, 0);
        }
      }
  
      const updatedData = {
        ...values,
        checkAmount: values.checkAmount || 0,
        fee: fee,
        issuer: values.checkIssuerName,
        idImage: idImage,
        checkImage: checkImage,
        holdUntilDate: values.holdUntilDate ? values.holdUntilDate.toISOString() : null,
        transactionDate: values.transactionDate ? values.transactionDate.toISOString() : null,
        createdAt: Timestamp.fromDate(transactionDate),
        updatedAt: serverTimestamp(),
      };
      
       updateDocumentNonBlocking(transactionToEditRef, updatedData);

       toast({
        title: 'Transaction Updated',
        description: 'The transaction has been successfully updated.',
        duration: 2000,
        variant: 'success'
      });
       router.push('/transactions');
    } else {
        const transactionData = {
          ...values,
          checkAmount: values.checkAmount || 0,
          userId: user.uid,
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }),
          fee: fee,
          issuer: values.checkIssuerName,
          idImage: idImage,
          checkImage: checkImage,
          holdUntilDate: values.holdUntilDate ? values.holdUntilDate.toISOString() : null,
          transactionDate: values.transactionDate ? values.transactionDate.toISOString() : new Date().toISOString(),
          createdAt: serverTimestamp(),
        };
        const transactionsColRef = collection(firestore, `users/${user.uid}/transactions`);
        addDocumentNonBlocking(transactionsColRef, transactionData);

        const { dismiss } = toast({
          title: 'Transaction Confirmed',
          description: 'The transaction has been successfully saved.',
          duration: 2000,
          variant: 'success',
          action: (
            <ToastAction altText="New Transaction" onClick={() => {
              resetAll();
              dismiss();
            }}>
              New Transaction
            </ToastAction>
          ),
        });
        resetAll();
    }
  };

  const resetAll = () => {
    setCheckImage(null);
    setIdImage(null);
    setError(null);
    setAppliedData(new Set());
    setExtractedData(null);
    form.reset({
      transactionType: "Standard",
      holdType: "Full Hold",
      feeType: "standard",
      checkDate: "",
      transactionDate: new Date(),
      timeOfTransaction: "",
      checkNumber: "",
      customerName: "",
      customerAddress: "",
      customerPhone: "",
      customerSsn: "",
      checkIssuerName: "",
      checkIssuerAddress: "",
      checkIssuerPhone: "",
      idNumber: "",
      expirationDate: "",
      dob: "",
      comment: "",
      checkAmount: undefined,
      customFee: 0,
      holdUntilDate: undefined,
      accountNumber: "",
      routingNumber: "",
      bankName: "",
      isSigned: false,
    });
    setCheckAmountDisplay("");
    setCustomFeeDisplay("0.00");
    setDateForDisplay("");
    if (editId) {
      router.push('/transactions/new');
    }
    window.scrollTo(0, 0);
  };
  
  const isScanDisabled = !checkImage || isPending;
  
  const getInputClass = (fieldName: keyof FormData) => {
    return cn(
        'pl-10',
        appliedData.has(fieldName) && 'text-emerald-700 font-medium'
    );
  };
  
  const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>, setDisplay: (value: string) => void, fieldName: 'checkAmount' | 'customFee') => {
    const value = e.target.value;
    const sanitizedValue = value.replace(/[^0-9.]/g, '');
    const parts = sanitizedValue.split('.');
    if (parts.length > 2) return;
    if (parts[1] && parts[1].length > 2) parts[1] = parts[1].substring(0, 2);
    
    const finalValue = parts.join('.');
    setDisplay(finalValue);
  
    const numericValue = parseFloat(finalValue);
    form.setValue(fieldName, !isNaN(numericValue) ? numericValue : undefined, { shouldValidate: true });
    if (finalValue === '') {
      setDisplay("");
      form.setValue(fieldName, undefined, { shouldValidate: true });
    }
  };
  
  const handleAmountBlur = (display: string, setDisplay: (value: string) => void, name: 'checkAmount' | 'customFee') => {
    const numericValue = parseFloat(display);
    if (!isNaN(numericValue)) {
      setDisplay(numericValue.toFixed(2));
      form.setValue(name, numericValue, { shouldValidate: true });
    } else if (name === 'customFee') {
      setDisplay("0.00");
      form.setValue(name, 0, { shouldValidate: true });
    } else {
      setDisplay("");
      form.setValue(name, undefined, { shouldValidate: true });
    }
  };

  const ExtractedDataDisplay = ({ data }: { data: ProcessDocumentOutput }) => {
    const [currentTime, setCurrentTime] = useState('');
  
    useEffect(() => {
      const timer = setInterval(() => {
        setCurrentTime(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }));
      }, 1000);
      return () => clearInterval(timer);
    }, []);

    const formatCurrency = (value: any) => {
        if (value === undefined || value === null) return "$0.00";
        const num = Number(value);
        if (isNaN(num)) return String(value);
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(num);
    }
  
    const DetailItem = ({ label, value, className }: { label: string, value: any, className?: string }) => {
      if (value === undefined || value === null || value === 'N/A' || value === '') return null;
      let displayValue = String(value);
      
      let valueClassName = "font-medium";
      if (label.toLowerCase() === 'amount') {
          displayValue = formatCurrency(value) || displayValue;
          valueClassName = "font-medium text-blue-600";
      } else if (typeof value === 'boolean') {
          displayValue = value ? 'Yes' : 'No';
      }

      return (
        <div className={className}>
          <p className="text-muted-foreground capitalize">{label.replace(/_/g, ' ')}</p>
          <p className={valueClassName}>
            {displayValue}
          </p>
        </div>
      );
    };

    const customerFullName = [data.validation_data?.first_name, data.validation_data?.middle_name, data.validation_data?.last_name]
      .filter(name => name && name !== 'N/A')
      .join(' ');
  
    return (
        <Card className="border-blue-500 bg-blue-500/5">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-800">
                    <Sparkles />
                    Extracted Data
                </CardTitle>
                <CardDescription>Review the data extracted by the AI. Click "Apply Data" to populate the form.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
                <div className="space-y-3">
                    <DetailItem label="Customer Name" value={customerFullName} className="col-span-full" />
                    <DetailItem label="Customer Address" value={data.validation_data?.customer_address} className="col-span-full" />
                    <div className="grid grid-cols-2 gap-x-4 gap-y-3 pt-2">
                      <DetailItem label="DL Number" value={data.validation_data?.dl_number} />
                      <DetailItem label="Expiration Date" value={data.validation_data?.expiration_date} />
                      <DetailItem label="Date of Birth" value={data.validation_data?.dob} />
                      <DetailItem label="Amount" value={data.extracted_data?.amount} />
                      <DetailItem label="Check Date" value={data.extracted_data?.check_date} />
                      <DetailItem label="Is Signed" value={data.validation_data?.signature_present} />
                      <DetailItem label="Issuer Name" value={data.extracted_data?.check_issuer} />
                      <DetailItem label="Issuer Address" value={data.extracted_data?.issuer_address} />
                      <DetailItem label="Bank Name" value={data.extracted_data?.bank_name} />
                      <DetailItem label="Check Number" value={data.extracted_data?.check_number} />
                      <DetailItem label="Account Number" value={data.extracted_data?.account_number} />
                      <DetailItem label="Routing Number" value={data.extracted_data?.routing_number} />
                      {currentTime && <DetailItem label="Device Real Time" value={currentTime} />}
                    </div>
                </div>
            </CardContent>
            <CardFooter className="flex justify-end gap-2">
                <Button variant="ghost" onClick={() => setExtractedData(null)}>Discard</Button>
                <Button onClick={() => handleApplyData(extractedData)} className="bg-blue-600 hover:bg-blue-700">Apply Data</Button>
            </CardFooter>
        </Card>
    );
  };


  if (!isClient || (editId && isEditLoading)) {
    return <div className="flex justify-center items-center h-96">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>;
  }

  return (
    <div className="space-y-6">
       <header>
        <h1 className="text-3xl font-bold tracking-tight">{editId ? 'Edit Transaction' : 'New Transaction'}</h1>
        <p className="text-muted-foreground">
          {editId ? 'Modify the details of the existing transaction.' : 'Use your camera or upload images, then click "Scan Images" to extract information.'}
        </p>
      </header>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="text-primary"/>
                  AI-Powered Capture
                </CardTitle>
                <CardDescription>
                  Use your camera or upload images, then click "Scan Images" to extract information.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 bg-primary/10 text-primary h-8 w-8 rounded-full flex items-center justify-center font-bold">1</div>
                      <div>
                        <h3 className="font-semibold">Check Image</h3>
                        {checkImage ? (
                          <div className="mt-2 flex items-center gap-2 text-green-600">
                            <CheckCircle className="h-5 w-5" />
                            <span className="font-medium">check-camera.jpg</span>
                          </div>
                        ) : (
                          <p className="text-sm text-muted-foreground">Upload or capture the front of the check.</p>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button type="button" variant="outline" onClick={() => checkUploadRef.current?.click()}><Camera className="mr-2"/> Upload</Button>
                      <input ref={checkUploadRef} type="file" accept="image/*" className="hidden" onChange={(e) => handleImageInput(e, setCheckImage, 'check')} />
                      <Button type="button" onClick={() => setIsCheckCameraOpen(true)} className="bg-green-500 hover:bg-green-600 text-white"><Camera className="mr-2"/> Capture</Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 bg-primary/10 text-primary h-8 w-8 rounded-full flex items-center justify-center font-bold">2</div>
                      <div>
                        <h3 className="font-semibold">ID Image (Optional)</h3>
                        {idImage ? (
                           <div className="mt-2 flex items-center gap-2 text-green-600">
                             <CheckCircle className="h-5 w-5" />
                             <span className="font-medium">id-camera.jpg</span>
                           </div>
                        ) : (
                          <p className="text-sm text-muted-foreground">Capture the customer's ID.</p>
                        )}
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button type="button" variant="outline" onClick={() => idUploadRef.current?.click()}><Camera className="mr-2"/> Upload</Button>
                      <input ref={idUploadRef} type="file" accept="image/*" className="hidden" onChange={(e) => handleImageInput(e, setIdImage, 'id')} />
                      <Button type="button" onClick={() => setIsIdCameraOpen(true)} className="bg-green-500 hover:bg-green-600 text-white"><Camera className="mr-2"/> Capture</Button>
                    </div>
                  </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button type="button" variant="ghost" onClick={resetAll}><Trash2 className="mr-2 text-destructive"/> Reset</Button>
                <Button type="button" onClick={handleExtract} disabled={isScanDisabled} className="bg-blue-800 hover:bg-blue-900 text-white">
                  <ScanLine className="mr-2"/> {isPending ? 'Scanning...' : 'Scan Images'}
                </Button>
              </CardFooter>
              {isPending && (
                <CardFooter>
                    <div className="w-full space-y-4">
                      <Skeleton className="h-6 w-1/3" />
                      <Skeleton className="h-10 w-full" />
                      <Skeleton className="h-10 w-full" />
                      <Skeleton className="h-10 w-full" />
                    </div>
                </CardFooter>
              )}
               {error && !isPending && (
                  <CardFooter>
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Error</AlertTitle>
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  </CardFooter>
                )}
            </Card>
            
            {extractedData && <ExtractedDataDisplay data={extractedData} />}
            
            <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Info className="text-primary"/>
                    Transaction Details
                  </CardTitle>
                  <CardDescription>
                    Verify the information below. The AI capture should fill most of this automatically.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="checkDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Check Date</FormLabel>
                              <FormControl>
                                 <Input 
                                    {...field}
                                    placeholder="MM/DD/YYYY"
                                    className={cn(appliedData.has('checkDate') && 'text-emerald-700 font-medium')} 
                                 />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                         <FormField
                          control={form.control}
                          name="transactionDate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Transaction Date</FormLabel>
                              <FormControl>
                                <DatePicker 
                                  date={field.value} 
                                  setDate={field.onChange} 
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <FormField
                          control={form.control}
                          name="timeOfTransaction"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Transaction Time</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} className={getInputClass('timeOfTransaction')}/>
                                </div>
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                       <FormField
                        control={form.control}
                        name="customerName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Customer Name</FormLabel>
                             <FormControl>
                              <div className="relative">
                                <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                <Input {...field} className={cn(getInputClass('customerName'), 'pr-10')} />
                                {isVerified('customerName') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                              </div>
                            </FormControl>
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="customerPhone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Customer Phone</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} className={cn(getInputClass('customerPhone'), 'pr-10')} />
                                  {isVerified('customerPhone') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                </div>
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="customerAddress"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Customer Address</FormLabel>
                               <FormControl>
                                  <div className="relative">
                                    <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input {...field} className={cn(getInputClass('customerAddress'), 'pr-10')}/>
                                    {isVerified('customerAddress') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                  </div>
                                </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                          control={form.control}
                          name="checkIssuerName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Check Issuer Name</FormLabel>
                               <FormControl>
                                <div className="relative">
                                  <Building className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} className={cn(getInputClass('checkIssuerName'), 'pr-10')}/>
                                   {isVerified('checkIssuerName') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                </div>
                              </FormControl>
                            </FormItem>
                          )}
                        />
                         <FormField
                          control={form.control}
                          name="checkIssuerPhone"
                          render={({ field }) => (
                              <FormItem>
                              <FormLabel>Check Issuer Phone</FormLabel>
                              <FormControl>
                                  <div className="relative">
                                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                      <Input {...field} className={cn(getInputClass('checkIssuerPhone'), 'pr-10')} />
                                      {isVerified('checkIssuerPhone') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                  </div>
                                  </FormControl>
                              </FormItem>
                          )}
                          />
                      </div>
                      <FormField
                        control={form.control}
                        name="checkIssuerAddress"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Check Issuer Address</FormLabel>
                             <FormControl>
                                <div className="relative">
                                  <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} className={cn(getInputClass('checkIssuerAddress'), 'pr-10')}/>
                                  {isVerified('checkIssuerAddress') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                </div>
                              </FormControl>
                          </FormItem>
                        )}
                      />
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                          control={form.control}
                          name="idNumber"
                          render={({ field }) => (
                              <FormItem>
                              <FormLabel>Driving License Number</FormLabel>
                              <FormControl>
                                  <div className="relative">
                                  <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} className={cn(getInputClass('idNumber'), 'pr-10')} />
                                  {isVerified('idNumber') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                  </div>
                              </FormControl>
                              </FormItem>
                          )}
                          />
                          <FormField
                          control={form.control}
                          name="expirationDate"
                          render={({ field }) => (
                              <FormItem>
                              <FormLabel>Expiration Date</FormLabel>
                              <FormControl>
                                  <div className="relative">
                                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} placeholder="MM/DD/YYYY" className={cn(getInputClass('expirationDate'), 'pr-10')} />
                                  {isVerified('expirationDate') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                  </div>
                              </FormControl>
                              </FormItem>
                          )}
                          />
                      </div>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                          control={form.control}
                          name="dob"
                          render={({ field }) => (
                              <FormItem>
                              <FormLabel>Date of Birth</FormLabel>
                              <FormControl>
                                  <div className="relative">
                                  <Clock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} placeholder="MM/DD/YYYY" className={cn(getInputClass('dob'), 'pr-10')} />
                                  {isVerified('dob') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                  </div>
                              </FormControl>
                              </FormItem>
                          )}
                          />
                          <FormField
                          control={form.control}
                          name="customerSsn"
                          render={({ field }) => (
                              <FormItem>
                              <FormLabel>Customer SSN</FormLabel>
                              <FormControl>
                                  <div className="relative">
                                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} className={cn(getInputClass('customerSsn'), 'pr-10')} />
                                  {isVerified('customerSsn') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                  </div>
                              </FormControl>
                              </FormItem>
                          )}
                          />
                      </div>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name="routingNumber"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Routing Number</FormLabel>
                                 <FormControl>
                                  <div className="relative">
                                    <Banknote className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input {...field} className={cn(getInputClass('routingNumber'), 'pr-10')} />
                                    {isVerified('routingNumber') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                  </div>
                                </FormControl>
                              </FormItem>
                            )}
                          />
                         <FormField
                          control={form.control}
                          name="accountNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Account Number</FormLabel>
                               <FormControl>
                                <div className="relative">
                                  <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} className={cn(getInputClass('accountNumber'), 'pr-10')} />
                                  {isVerified('accountNumber') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                </div>
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="checkNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Check Number</FormLabel>
                               <FormControl>
                                <div className="relative">
                                  <CreditCard className="absolute left-3 top-1/-translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input {...field} className={cn(getInputClass('checkNumber'), 'pr-10')} />
                                  {isVerified('checkNumber') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                </div>
                              </FormControl>
                            </FormItem>
                          )}
                        />
                         <FormField
                          control={form.control}
                          name="bankName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bank Name</FormLabel>
                               <FormControl>
                                  <div className="relative">
                                    <Landmark className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input {...field} className={cn(getInputClass('bankName'), 'pr-10')} />
                                    {isVerified('bankName') && <CheckCircle className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-green-500" />}
                                  </div>
                                </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <FormField
                          control={form.control}
                          name="isSigned"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className={cn("text-base flex items-center gap-2", appliedData.has('isSigned') && 'text-emerald-700 font-medium')}>
                                  <CheckCircle />
                                  Is Check Signed?
                                </FormLabel>
                                <FormMessage />
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                       <FormField
                        control={form.control}
                        name="comment"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Comment (Optional)</FormLabel>
                             <FormControl>
                                <div className="relative">
                                  <MessageSquare className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                                  <Textarea {...field} className="pl-10"/>
                                </div>
                              </FormControl>
                          </FormItem>
                        )}
                      />
                </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign />
                  Summary & Action
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormItem>
                  <FormLabel>Check Amount</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input 
                        type="text" 
                        value={checkAmountDisplay}
                        onChange={(e) => handleAmountChange(e, setCheckAmountDisplay, 'checkAmount')}
                        onBlur={() => handleAmountBlur(checkAmountDisplay, setCheckAmountDisplay, 'checkAmount')}
                        placeholder="0.00" 
                        className={cn("pl-10 font-bold", appliedData.has('checkAmount') && 'text-emerald-700')} 
                      />
                    </div>
                  </FormControl>
                </FormItem>
                <FormField
                  control={form.control}
                  name="feeType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fee Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="standard">Standard Fee = 2.0 %</SelectItem>
                          <SelectItem value="special">Special Fee = 1.00%</SelectItem>
                          <SelectItem value="waived">Fee Waived = 0.0%</SelectItem>
                          <SelectItem value="custom">(Custom / Manual ) Fee</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
                 {feeType === "custom" && (
                  <FormItem>
                    <FormLabel>Custom Fee Amount</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          type="text"
                          value={customFeeDisplay}
                          onChange={(e) => handleAmountChange(e, setCustomFeeDisplay, 'customFee')}
                          onBlur={() => handleAmountBlur(customFeeDisplay, setCustomFeeDisplay, 'customFee')}
                          placeholder="0.00"
                          className="pl-10"
                        />
                      </div>
                    </FormControl>
                  </FormItem>
                )}
                <Separator />
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Check Amount:</span>
                    <span className="font-medium">{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(checkAmountValue)}</span>
                  </div>
                  <div className="flex justify-between text-red-400">
                    <span>Fee:</span>
                    <span className="font-medium">-{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(fee)}</span>
                  </div>
                   <div className="flex justify-between font-bold text-lg">
                    <span>Net Amount:</span>
                    <span>{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(netAmount)}</span>
                  </div>
                </div>
                 <FormField
                  control={form.control}
                  name="transactionType"
                  render={({ field }) => (
                    <FormItem className="space-y-2">
                      <FormLabel>Transaction Type</FormLabel>
                      <FormControl>
                         <div className="grid grid-cols-2 gap-2">
                           <Button type="button" variant={field.value === 'Standard' ? 'default' : 'outline'} onClick={() => field.onChange('Standard')}>Standard</Button>
                           <Button type="button" variant={field.value === 'Hold' ? 'default' : 'outline'} onClick={() => field.onChange('Hold')}>Hold / Buy Back</Button>
                         </div>
                      </FormControl>
                    </FormItem>
                  )}
                />
                {transactionType === 'Hold' && (
                  <>
                  <FormField
                    control={form.control}
                    name="holdType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hold Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a hold type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Full Hold">Full Hold</SelectItem>
                            <SelectItem value="Partial Hold">Partial Hold</SelectItem>
                            <SelectItem value="Customer Buyback">Customer Buyback</SelectItem>
                          </SelectContent>
                        </Select>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="holdUntilDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hold Until Date</FormLabel>
                        <FormControl>
                          <DatePicker 
                            date={field.value} 
                            setDate={field.onChange}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  </>
                )}
                <div className="bg-primary/10 text-primary p-4 rounded-lg text-center">
                  <p className="text-sm">Cash to Customer:</p>
                  <p className="text-3xl font-bold">{new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(Math.floor(netAmount))}</p>
                </div>
              </CardContent>
              <CardFooter className="flex-col gap-2 !p-4">
                <Button variant="outline" type="button" className="w-full h-12 text-base" onClick={resetAll}>
                  <Trash2 className="mr-2"/> {editId ? 'Cancel' : 'Clear & Reset Form'}
                </Button>
                <Button
                  type="submit"
                  variant="default"
                  className="w-full h-12 text-base"
                >
                  <ArrowRight className="mr-2 h-4 w-4"/> {editId ? 'Update Transaction' : 'Confirm Transaction'}
                </Button>
              </CardFooter>
            </Card>
          </div>
        </form>
      </Form>
      
      <Dialog open={isIdCameraOpen} onOpenChange={setIsIdCameraOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Capture ID</DialogTitle>
          </DialogHeader>
          <CameraCapture onCapture={handleIdCapture} captureType="id"/>
        </DialogContent>
      </Dialog>

      <Dialog open={isCheckCameraOpen} onOpenChange={setIsCheckCameraOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Capture Check</DialogTitle>
          </DialogHeader>
          <CameraCapture onCapture={handleCheckCapture} captureType="check"/>
        </DialogContent>
      </Dialog>

      <Dialog open={!!captureConfirmation} onOpenChange={() => setCaptureConfirmation(null)}>
        <DialogContent className="top-4 translate-y-0 sm:max-w-sm !w-[calc(100%-2rem)] max-w-sm left-1/2 -translate-x-1/2">
          <DialogHeader>
            <DialogTitle>{captureConfirmation?.title}</DialogTitle>
          </DialogHeader>
          <div>
            <p>{captureConfirmation?.description}</p>
          </div>
           <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </DialogClose>
        </DialogContent>
      </Dialog>
    </div>
  );
}

    