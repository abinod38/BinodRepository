'use client';

import { useState, useEffect } from 'react';
import { format } from 'date-fns';

export function DateTimeDisplay() {
  const [currentDate, setCurrentDate] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDate(new Date());
    }, 1000);

    return () => {
      clearInterval(timer);
    };
  }, []);

  return (
    <div className="text-right">
      <p className="text-sm font-medium text-green-700">{format(currentDate, 'MMMM do, yyyy')}</p>
      <p className="text-sm font-semibold text-black">{format(currentDate, 'h:mm:ss a')}</p>
    </div>
  );
}
