
"use client"

import type { ReactNode } from "react"
import { Landmark } from "lucide-react"

import {
  SidebarProvider,
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarTrigger,
  SidebarInset,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import { Nav } from "./_components/nav"
import { UserNav } from "./_components/user-nav"
import { Button } from "@/components/ui/button"
import { useUser } from "@/firebase/auth/use-user";
import { redirect } from "next/navigation";
import { CurrentUser } from "./_components/current-user"
import { DateTimeDisplay } from "./_components/date-time-display";

export default function AppLayout({ children }: { children: ReactNode }) {
  const { user, isUserLoading } = useUser();

  if (isUserLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p>Loading...</p>
      </div>
    );
  }

  if (!user) {
    return redirect("/login");
  }

  return (
    <SidebarProvider>
      <Sidebar
        collapsible="icon"
        className="border-sidebar-border"
      >
        <SidebarHeader className="h-16 p-4">
          <a href="/dashboard" className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="size-9 shrink-0 rounded-lg bg-primary text-primary-foreground"
              aria-label="Home"
            >
              <Landmark className="size-5" />
            </Button>
            <span className="text-lg font-semibold">Wrangler</span>
          </a>
        </SidebarHeader>
        <SidebarContent>
          <Nav />
        </SidebarContent>
        <SidebarFooter className="p-2 flex-col gap-2">
          <CurrentUser />
          <SidebarSeparator />
          <UserNav />
        </SidebarFooter>
      </Sidebar>
      <SidebarInset>
        <header className="sticky top-0 z-10 flex h-16 items-center justify-between gap-4 border-b bg-background/80 px-4 backdrop-blur-sm sm:px-6">
          <SidebarTrigger className="md:hidden -ml-2 text-blue-500 hover:text-blue-500/90 text-2xl [&>svg]:h-8 [&>svg]:w-8">
            <span className="ml-2">Menu</span>
          </SidebarTrigger>
          <div className="flex-1" />
          <DateTimeDisplay />
        </header>
        <main className="flex-1 p-4 sm:p-6">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
