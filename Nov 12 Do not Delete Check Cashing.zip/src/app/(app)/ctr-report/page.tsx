
'use client';

import { useState } from 'react';
import { AlertTriangle, FileCheck2, FileX2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function CTRReportPage() {
  const [activeTab, setActiveTab] = useState('needed');
  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">CTR Reports</h1>
          <p className="text-muted-foreground">
            Manage and track Currency Transaction Reports for compliance.
          </p>
        </div>
        <Button variant="destructive">
          <Trash2 className="mr-2 h-4 w-4" />
          Clear All Test Reports
        </Button>
      </header>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 max-w-lg">
          <TabsTrigger value="needed">
            <AlertTriangle className="mr-2 h-4 w-4" />
            CTR Needed (1)
          </TabsTrigger>
          <TabsTrigger value="filed">
            <FileCheck2 className="mr-2 h-4 w-4" />
            CTR Filed (9)
          </TabsTrigger>
          <TabsTrigger value="ignored">
            <FileX2 className="mr-2 h-4 w-4" />
            Ignored (7)
          </TabsTrigger>
        </TabsList>
        <TabsContent value="needed">
          <Card>
            <CardHeader>
              <CardTitle>Reports Requiring Action</CardTitle>
              <CardDescription>
                These customers have received cash totaling over $10,000 in a single day. CTRs must be filed within 15 days of the transaction date.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Card className="p-4">
                <div className="flex flex-col sm:flex-row justify-between sm:items-start">
                  <div>
                    <h3 className="font-semibold">Top Quality</h3>
                    <p className="text-sm">Transaction Date: October 27th, 2025</p>
                    <p className="text-sm">
                      Total Cash Disbursed: <span className="font-medium">{formatCurrency(11500)}</span> across 1 transaction(s)
                    </p>
                    <p className="text-sm text-red-500 font-medium">Due Date: November 11th, 2025</p>
                  </div>
                  <div className="flex items-center gap-2 mt-4 sm:mt-0">
                    <Button className="bg-teal-600 hover:bg-teal-700">Mark as Filed</Button>
                    <Button variant="ghost">Ignore Report</Button>
                    <Button variant="destructive" size="icon">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="filed">
          <Card>
            <CardContent className="pt-6">
              <p>Filed reports will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="ignored">
          <Card>
            <CardContent className="pt-6">
              <p>Ignored reports will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
