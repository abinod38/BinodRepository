
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function ChecksCashedPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Checks Cashed</CardTitle>
        <CardDescription>
          A log of all cashed checks.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p>This page is under construction.</p>
      </CardContent>
    </Card>
  );
}
