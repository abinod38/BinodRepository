
'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useUser, useFirestore, useDoc, useMemoFirebase, updateDocumentNonBlocking } from '@/firebase';
import { doc } from 'firebase/firestore';

const pinChangeSchema = z.object({
  currentPin: z.string().length(4, 'PIN must be 4 digits'),
  newPin: z.string().length(4, 'New PIN must be 4 digits'),
  confirmNewPin: z.string().length(4, 'PIN must be 4 digits'),
}).refine(data => data.newPin === data.confirmNewPin, {
  message: "New PINs don't match",
  path: ['confirmNewPin'],
});

type PinChangeFormValues = z.infer<typeof pinChangeSchema>;

export default function SettingsPage() {
  const { toast } = useToast();
  const { user } = useUser();
  const firestore = useFirestore();
  
  const userDocRef = useMemoFirebase(() => {
    if (!user) return null;
    return doc(firestore, `users/${user.uid}`);
  }, [user, firestore]);
  
  const { data: userData } = useDoc<any>(userDocRef);

  const form = useForm<PinChangeFormValues>({
    resolver: zodResolver(pinChangeSchema),
    defaultValues: {
      currentPin: '',
      newPin: '',
      confirmNewPin: '',
    },
  });

  const onSubmit = (data: PinChangeFormValues) => {
    const currentPin = userData?.pin || '1234';

    if (data.currentPin !== currentPin) {
      form.setError('currentPin', {
        type: 'manual',
        message: 'Incorrect current PIN.',
      });
      return;
    }
    
    if (!userDocRef) {
        toast({ variant: 'destructive', title: 'Error', description: 'User not found.' });
        return;
    }

    updateDocumentNonBlocking(userDocRef, { pin: data.newPin });

    toast({
      title: 'PIN Updated',
      description: 'Your PIN has been successfully changed.',
    });
    form.reset();
  };

  return (
    <div className="space-y-6">
       <header>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">
          Manage your application settings.
        </p>
      </header>
      <Card className="max-w-md">
        <CardHeader>
          <CardTitle>Change Security PIN</CardTitle>
          <CardDescription>
            This PIN is used to authorize sensitive actions like deleting a transaction.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="currentPin"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current PIN</FormLabel>
                    <FormControl>
                      <Input type="password" maxLength={4} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="newPin"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>New PIN</FormLabel>
                    <FormControl>
                      <Input type="password" maxLength={4} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="confirmNewPin"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Confirm New PIN</FormLabel>
                    <FormControl>
                      <Input type="password" maxLength={4} {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full">Save New PIN</Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
