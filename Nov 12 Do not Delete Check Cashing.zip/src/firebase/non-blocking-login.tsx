
'use client';
import {
  Auth,
  signInAnonymously,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
} from 'firebase/auth';
import { Firestore, doc, setDoc } from 'firebase/firestore';

type ErrorCallback = (error: any) => void;
type SuccessCallback = () => void;

/** Initiate anonymous sign-in (non-blocking). */
export function initiateAnonymousSignIn(authInstance: Auth, onError: ErrorCallback): void {
  signInAnonymously(authInstance).catch(onError);
}

/** Initiate email/password sign-up (non-blocking). */
export function initiateEmailSignUp(
  authInstance: Auth,
  firestore: Firestore,
  email: string,
  password: string,
  name: string,
  onSuccess: SuccessCallback,
  onError: ErrorCallback
): void {
  createUserWithEmailAndPassword(authInstance, email, password)
    .then(async (userCredential) => {
      const user = userCredential.user;
      await updateProfile(user, { displayName: name });
      const userDocRef = doc(firestore, "users", user.uid);
      const userData = {
        id: user.uid,
        name: name,
        email: email,
      };
      // Use set with merge to non-destructively create or update the user profile.
      await setDoc(userDocRef, userData, { merge: true });
      onSuccess();
    })
    .catch(onError);
}


/** Initiate email/password sign-in (non-blocking). */
export function initiateEmailSignIn(
  authInstance: Auth,
  email: string,
  password: string,
  onError: ErrorCallback
): void {
  signInWithEmailAndPassword(authInstance, email, password)
    .catch(onError);
}
