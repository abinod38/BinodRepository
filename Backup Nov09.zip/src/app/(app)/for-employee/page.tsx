import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function ForEmployeePage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>For Employee</CardTitle>
        <CardDescription>
          Important notes and information for employees.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p>Content for employees will be displayed here.</p>
      </CardContent>
    </Card>
  );
}
