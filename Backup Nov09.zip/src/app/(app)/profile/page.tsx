
'use client';

import { useState } from 'react';
import {
  Users,
  Building,
  Search,
  ChevronRight,
  BarChart,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { customers } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

export default function CustomersPage() {
  const [activeTab, setActiveTab] = useState('customers');

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 max-w-sm">
          <TabsTrigger value="customers">
            <Users className="mr-2 h-4 w-4" />
            Customers
          </TabsTrigger>
          <TabsTrigger value="check-issuers">
            <Building className="mr-2 h-4 w-4" />
            Check Issuers
          </TabsTrigger>
        </TabsList>
        <TabsContent value="customers">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
                <div>
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <Users className="text-muted-foreground" /> All Customers
                  </h2>
                  <p className="text-muted-foreground">
                    A list of all customers in your system.
                  </p>
                </div>
                <div className="relative w-full md:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search by name..." className="pl-10" />
                </div>
              </div>

              <div className="flex items-center gap-2 mb-4">
                <span className="text-sm font-medium">Filters:</span>
                <Button variant="secondary" size="sm">
                  All
                </Button>
                <Button variant="outline" size="sm">
                  Inactive &gt;15 days
                </Button>
                <Button variant="outline" size="sm">
                  Inactive &gt;30 days
                </Button>
              </div>

              <div className="space-y-4">
                {customers.map((customer, index) => (
                  <Card key={customer.id} className="p-4 flex items-center justify-between hover:bg-muted/50 cursor-pointer">
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <span className="text-muted-foreground hidden sm:inline">{index + 1}.</span>
                      <Avatar>
                        <AvatarImage src={customer.avatar} />
                        <AvatarFallback>{customer.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="truncate">
                        <p className="font-semibold truncate">{customer.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Last seen: {customer.lastSeen}
                        </p>
                      </div>
                    </div>
                    <div className="hidden lg:flex items-center gap-6">
                      <div className="text-right w-32">
                        <p className="font-bold">{formatCurrency(customer.totalVolume)}</p>
                        <p className="text-xs text-muted-foreground flex items-center justify-end gap-1">
                          <BarChart className="h-3 w-3" /> Total Volume
                        </p>
                      </div>
                      <div className="text-right w-28">
                        <p className="font-bold flex items-center justify-end gap-1 text-green-500">
                          <CheckCircle className="h-4 w-4" /> {customer.goodChecks}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Good Checks
                        </p>
                      </div>
                      <div className="text-right w-28">
                        <p className="font-bold flex items-center justify-end gap-1 text-red-500">
                          <AlertTriangle className="h-4 w-4" /> {customer.badChecks}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Bad Checks
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="text-muted-foreground ml-4" />
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="check-issuers">
          <Card>
            <CardContent className="pt-6">
              <p>Check Issuers will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
