
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function SmokeShopDailyReportPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Smoke Shop Daily Report</CardTitle>
        <CardDescription>
          Daily report for the Smoke Shop.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p>This page is under construction.</p>
      </CardContent>
    </Card>
  );
}
