
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

export default function DepositHistoryPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Deposit History</CardTitle>
        <CardDescription>
          View your past bank deposits.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p>This page is under construction.</p>
        <p>Checks to Deposit</p>
        <Tabs defaultValue="checks" className="mt-4">
          <TabsList>
            <TabsTrigger value="checks"># of checks</TabsTrigger>
            <TabsTrigger value="amount">Total Amount</TabsTrigger>
          </TabsList>
          <TabsContent value="checks">
            <p>Number of checks will be displayed here.</p>
          </TabsContent>
          <TabsContent value="amount">
            <p>Total amount will be displayed here.</p>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
