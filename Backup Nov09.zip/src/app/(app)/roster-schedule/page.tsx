import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function RosterSchedulePage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Roster / Schedule</CardTitle>
        <CardDescription>
          Manage your roster and schedule.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p>Roster and schedule information will be displayed here.</p>
      </CardContent>
    </Card>
  );
}
