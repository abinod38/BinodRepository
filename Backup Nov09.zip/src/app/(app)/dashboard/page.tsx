

"use client"

import { useMemo, useState } from "react"
import {
  AlertTriangle,
  ArrowRight,
  Ban,
  Calendar,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  FileBarChart,
  FileCheck,
  FileX,
  Landmark,
  LineChart,
  MinusCircle,
  PauseCircle,
  Repeat2,
  TrendingUp,
} from "lucide-react"
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"
import { collection, query, orderBy, Timestamp } from "firebase/firestore"
import { startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, subDays, format as formatDateFns, getDate } from "date-fns"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Separator } from "@/components/ui/separator";
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { Skeleton } from "@/components/ui/skeleton"

const formatCurrency = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(value)

export default function DashboardPage() {
  const { user } = useUser();
  const firestore = useFirestore();
  const [summaryPeriod, setSummaryPeriod] = useState("today");

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<any>(transactionsQuery);
  
  const dailyVolume = useMemo(() => {
    if (!transactions) {
      return [];
    }

    const last30Days = Array.from({ length: 30 }, (_, i) => {
      const d = subDays(new Date(), i);
      return formatDateFns(d, 'yyyy-MM-dd');
    }).reverse();

    const volumeByDay = last30Days.reduce((acc, day) => {
      acc[day] = 0;
      return acc;
    }, {} as Record<string, number>);

    transactions.forEach(t => {
      if (t.createdAt) {
        const transactionDate = (t.createdAt as Timestamp).toDate();
        const dayStr = formatDateFns(transactionDate, 'yyyy-MM-dd');
        if (dayStr in volumeByDay) {
          volumeByDay[dayStr] += t.checkAmount || 0;
        }
      }
    });
    
    return Object.entries(volumeByDay).map(([date, volume]) => {
      const d = new Date(`${date}T00:00:00`); // Ensure correct date parsing across timezones
      const dayOfMonth = getDate(d);
      
      const shouldShowLabel = dayOfMonth % 5 === 0 || dayOfMonth === 1;

      return {
        date: formatDateFns(d, 'MM/dd'),
        displayDate: shouldShowLabel ? formatDateFns(d, 'MM/dd') : '',
        volume,
      }
    });

  }, [transactions]);

  const { yAxisTicks, maxVolume } = useMemo(() => {
    if (!dailyVolume.length) return { yAxisTicks: [0, 5000, 10000, 15000, 20000], maxVolume: 20000 };

    const max = Math.max(...dailyVolume.map(d => d.volume));
    const top = Math.ceil(max / 5000) * 5000;
    const ticks = Array.from({ length: top / 5000 + 1 }, (_, i) => i * 5000);
    
    return { yAxisTicks: ticks.length > 1 ? ticks : [0, 5000], maxVolume: top > 0 ? top : 5000 };
  }, [dailyVolume]);


  const calculateStats = (filteredTransactions: any[]) => {
    const totalCheckAmount = filteredTransactions.reduce((acc, t) => acc + (t.checkAmount || 0), 0);
    const totalFee = filteredTransactions.reduce((acc, t) => acc + (t.fee || 0), 0);
    const totalCashedOut = totalCheckAmount - totalFee;
    const depositedChecks = filteredTransactions.filter(t => t.bankDeposited).length;
    const depositedAmount = filteredTransactions.filter(t => t.bankDeposited).reduce((acc, t) => acc + (t.checkAmount || 0), 0);
    
    return {
      count: filteredTransactions.length,
      checkAmount: totalCheckAmount,
      cashedOut: totalCashedOut,
      fee: totalFee,
      depositedChecks,
      depositedAmount,
    };
  };

  const {
    allTimeCount,
    todayStats,
    allTimeStats,
  } = useMemo(() => {
    if (!transactions) {
      return {
        allTimeCount: 0,
        todayStats: { count: 0, checkAmount: 0, cashedOut: 0, fee: 0, depositedChecks: 0, depositedAmount: 0 },
        allTimeStats: { badChecks: 0, goodChecks: 0, onHold: 0, readyForDeposit: 0, precaution: 0, owedToCustomers: 0, customerBuybacks: { count: 0, amount: 0 } },
      };
    }

    const todayStart = startOfDay(new Date());
    const todayEnd = endOfDay(new Date());

    const todaysTransactions = transactions.filter(t => {
      if (!t.createdAt) return false;
      const transactionDate = (t.createdAt as Timestamp).toDate();
      return transactionDate >= todayStart && transactionDate <= todayEnd;
    });

    const badChecksCount = transactions.filter(t => t.returnedFromBank).length;
    const onHoldChecks = transactions.filter(t => t.transactionType === 'Hold');
    const onHoldCount = onHoldChecks.length;
    const readyForDepositCount = transactions.filter(t => !t.bankDeposited && !t.returnedFromBank).length;
    const precautionCount = transactions.filter(t => t.precaution).length;

    const owedToCustomers = onHoldChecks
      .filter(t => t.holdType === 'Full Hold' || t.holdType === 'Partial Hold')
      .reduce((acc, t) => acc + (t.checkAmount || 0), 0);

    const customerBuybackChecks = onHoldChecks.filter(t => t.holdType === 'Customer Buyback');
    const customerBuybacks = {
        count: customerBuybackChecks.length,
        amount: customerBuybackChecks.reduce((acc, t) => acc + (t.checkAmount || 0), 0),
    };


    return {
      allTimeCount: transactions.length,
      todayStats: calculateStats(todaysTransactions),
      allTimeStats: {
        badChecks: badChecksCount,
        goodChecks: transactions.length - badChecksCount,
        onHold: onHoldCount,
        readyForDeposit: readyForDepositCount,
        precaution: precautionCount,
        owedToCustomers: owedToCustomers,
        customerBuybacks: customerBuybacks,
      },
    };
  }, [transactions]);


  const summaryStats = useMemo(() => {
    if (!transactions) {
      return { count: 0, checkAmount: 0, cashedOut: 0, fee: 0, depositedChecks: 0, depositedAmount: 0 };
    }

    const now = new Date();
    let startDate, endDate;

    switch(summaryPeriod) {
      case 'yesterday':
        startDate = startOfDay(subDays(now, 1));
        endDate = endOfDay(subDays(now, 1));
        break;
      case 'week':
        startDate = startOfWeek(now);
        endDate = endOfWeek(now);
        break;
      case 'month':
        startDate = startOfMonth(now);
        endDate = endOfMonth(now);
        break;
      case 'today':
      default:
        startDate = startOfDay(now);
        endDate = endOfDay(now);
        break;
    }

    const filtered = transactions.filter(t => {
      if (!t.createdAt) return false;
      const transactionDate = (t.createdAt as Timestamp).toDate();
      return transactionDate >= startDate && transactionDate <= endDate;
    });

    return calculateStats(filtered);
  }, [transactions, summaryPeriod]);


  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Here's a summary of your check cashing activity.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Today's Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {isLoading ? (
                <div className="flex items-center gap-4">
                  <Skeleton className="h-12 w-12" />
                  <div className="space-y-2">
                    <Skeleton className="h-6 w-24" />
                    <Skeleton className="h-4 w-16" />
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-4">
                  <div className="text-5xl font-bold text-primary">#</div>
                  <div>
                    <p className="text-sm text-muted-foreground">Checks Cashed Today</p>
                    <p className="text-3xl font-bold">{todayStats.count}</p>
                    <p className="text-xs text-muted-foreground">{allTimeCount} all time</p>
                  </div>
                </div>
              )}
              {isLoading ? (
                 <div className="space-y-2">
                    <Skeleton className="h-6 w-32" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                 </div>
              ) : (
                <div>
                  <h3 className="font-semibold mb-2">Today's Financials</h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Total Check Amount</span>
                      <span className="font-medium">{formatCurrency(todayStats.checkAmount)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Cashed Out</span>
                      <span className="font-medium text-red-400">{formatCurrency(todayStats.cashedOut)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Cashing Fee</span>
                      <span className="font-medium text-green-400">{formatCurrency(todayStats.fee)}</span>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <span className="flex items-center gap-2"><Landmark className="h-4 w-4 text-muted-foreground" /> Deposited Checks</span>
                      <span className="font-medium">{todayStats.depositedChecks}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Deposited Amount</span>
                      <span className="font-medium">{formatCurrency(todayStats.depositedAmount)}</span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Financial Summary */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <LineChart className="h-5 w-5" />
                Financial Summary
              </CardTitle>
              <Select value={summaryPeriod} onValueChange={setSummaryPeriod}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Total Checks Cashed</span>
                    <span className="font-medium">{summaryStats.count}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Check Amount</span>
                    <span className="font-medium">{formatCurrency(summaryStats.checkAmount)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Cashed Out</span>
                    <span className="font-medium text-red-400">{formatCurrency(summaryStats.cashedOut)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Cashing Fee</span>
                    <span className="font-medium text-green-400">{formatCurrency(summaryStats.fee)}</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="flex items-center gap-2"><Landmark className="h-4 w-4 text-muted-foreground" /> Deposited Checks</span>
                    <span className="font-medium">{summaryStats.depositedChecks}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Deposited Amount</span>
                    <span className="font-medium">{formatCurrency(summaryStats.depositedAmount)}</span>
                  </div>
                </div>
            </CardContent>
          </Card>

          {/* Daily Volume */}
          <Card>
            <CardHeader>
              <CardTitle>Daily Volume (Last 30 Days)</CardTitle>
              <CardDescription>
                Total check amounts cashed each day.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  volume: {
                    label: "Volume",
                    color: "hsl(142.1 76.2% 36.3%)",
                  },
                }}
                className="h-[300px] w-full"
              >
                {isLoading ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <Skeleton className="w-full h-full" />
                  </div>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={dailyVolume} margin={{ top: 20, right: 20, left: -10, bottom: 5 }}>
                      <CartesianGrid vertical={false} />
                      <XAxis 
                        dataKey="displayDate" 
                        tickLine={{ stroke: 'hsl(var(--border))' }}
                        axisLine={{ stroke: 'hsl(var(--border))' }}
                        tickMargin={10}
                      />
                      <YAxis 
                        tickLine={{ stroke: 'hsl(var(--border))' }}
                        axisLine={{ stroke: 'hsl(var(--border))' }}
                        tickFormatter={(value) => `$${Number(value) / 1000}k`}
                        domain={[0, maxVolume]}
                        ticks={yAxisTicks}
                      />
                      <Tooltip
                        cursor={{ fill: "hsl(var(--card))" }}
                        content={<ChartTooltipContent 
                          formatter={(value) => formatCurrency(Number(value))}
                          labelFormatter={(label, payload) => <strong>Date: {payload[0]?.payload.date}</strong>}
                        />}
                      />
                      <Bar dataKey="volume" radius={[4, 4, 0, 0]} fill="var(--color-volume)" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Area */}
        <div className="space-y-6">
          {/* Check Status Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Check Status Summary (All Time)</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <Card className="bg-teal-500/10 border-teal-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <CircleDollarSign className="h-6 w-6 text-teal-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  {isLoading ? <div className="text-2xl font-bold"><Skeleton className="h-8 w-12" /></div> : <p className="text-2xl font-bold">{allTimeStats.readyForDeposit}</p>}
                  <p className="text-sm text-muted-foreground">Ready for Deposit</p>
                </CardContent>
              </Card>
               <Card className="bg-yellow-500/10 border-yellow-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <AlertTriangle className="h-6 w-6 text-yellow-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  {isLoading ? <div className="text-2xl font-bold"><Skeleton className="h-8 w-12" /></div> : <p className="text-2xl font-bold">{allTimeStats.precaution}</p>}
                  <p className="text-sm text-muted-foreground">Precaution</p>
                </CardContent>
              </Card>
               <Card className="bg-red-500/10 border-red-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <Ban className="h-6 w-6 text-red-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  {isLoading ? <div className="text-2xl font-bold"><Skeleton className="h-8 w-12" /></div> : <p className="text-2xl font-bold">{allTimeStats.badChecks}</p>}
                  <p className="text-sm text-muted-foreground">Bad Checks</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-500/10 border-blue-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <Repeat2 className="h-6 w-6 text-blue-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="text-2xl font-bold">0</p>
                  <p className="text-sm text-muted-foreground">Frequent Returns</p>
                </CardContent>
              </Card>
              <Card className="bg-purple-500/10 border-purple-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <PauseCircle className="h-6 w-6 text-purple-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  {isLoading ? <div className="text-2xl font-bold"><Skeleton className="h-8 w-12" /></div> : <p className="text-2xl font-bold">{allTimeStats.onHold}</p>}
                  <p className="text-sm text-muted-foreground">Hold</p>
                </CardContent>
              </Card>
              <Card className="bg-green-500/10 border-green-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <CheckCircle2 className="h-6 w-6 text-green-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                   {isLoading ? <div className="text-2xl font-bold"><Skeleton className="h-8 w-20" /></div> : <p className="text-2xl font-bold">{allTimeStats.goodChecks}</p>}
                  <p className="text-sm text-muted-foreground">Good Checks</p>
                </CardContent>
              </Card>
            </CardContent>
          </Card>

          {/* CTR Reports */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><AlertTriangle className="text-yellow-500"/>CTR Reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileBarChart className="h-5 w-5 text-yellow-500"/>
                  <div>
                    <p className="font-medium">CTR Needed</p>
                    <p className="text-xs text-muted-foreground">Transactions over $10k</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold">1</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground"/>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileCheck className="h-5 w-5 text-green-500"/>
                  <div>
                    <p className="font-medium">CTR Filed</p>
                    <p className="text-xs text-muted-foreground">Filed reports history</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold">9</span>
                   <ChevronRight className="h-4 w-4 text-muted-foreground"/>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileX className="h-5 w-5 text-red-500"/>
                  <div>
                    <p className="font-medium">CTR Ignored</p>
                    <p className="text-xs text-muted-foreground">Manually ignored reports</p>
                  </div>
                </div>
                 <div className="flex items-center gap-2">
                  <span className="font-bold">7</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground"/>
                </div>
              </div>
            </CardContent>
          </Card>

           {/* Returned Checks */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2"><TrendingUp />Returned Checks</CardTitle>
              <ArrowRight className="h-4 w-4 text-muted-foreground cursor-pointer"/>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">9</p>
              <p className="text-sm text-muted-foreground">checks pending payment</p>
              <Separator className="my-4"/>
              <div className="text-sm">
                <div className="flex justify-between">
                  <span>Total Receivable:</span>
                  <span className="font-medium text-red-400">{formatCurrency(19330.40)}</span>
                </div>
                <div className="flex justify-between mt-2">
                  <span>Checks with DA:</span>
                  <span className="font-medium">1</span>
                </div>
                <div className="flex justify-between">
                  <span>Amount with DA:</span>
                  <span className="font-medium">{formatCurrency(7300.00)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* On-Hold Financials */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2"><PauseCircle />On-Hold Financials</CardTitle>
              <ArrowRight className="h-4 w-4 text-muted-foreground cursor-pointer"/>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Owed to Customers</p>
                <div className="text-2xl font-bold text-green-400">
                    {isLoading ? <div className="h-8 w-32"><Skeleton className="h-8 w-32" /></div> : formatCurrency(allTimeStats.owedToCustomers)}
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Owed by Customers (Buybacks)</p>
                <div className="text-2xl font-bold text-yellow-400">
                    {isLoading ? <div className="h-8 w-32"><Skeleton className="h-8 w-32" /></div> : formatCurrency(allTimeStats.customerBuybacks.amount)}
                </div>
                <p className="text-xs text-muted-foreground">
                    {isLoading ? "" : `${allTimeStats.customerBuybacks.count} check(s)`}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
    

    




    

    

    




    
    




    


    






    
