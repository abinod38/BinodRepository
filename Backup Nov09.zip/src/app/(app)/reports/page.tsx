
'use client';

import { useState, useMemo, useEffect } from 'react';
import { Download, Search, FileText } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { DatePicker } from '@/components/ui/date-picker';
import { cn } from "@/lib/utils";
import { format as formatDateFns, parseISO, startOfDay, endOfDay, subDays, isValid } from 'date-fns';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, Timestamp } from 'firebase/firestore';
import { Skeleton } from '@/components/ui/skeleton';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { useToast } from '@/hooks/use-toast';


declare module 'jspdf' {
    interface jsPDF {
      autoTable: (options: any) => jsPDF;
    }
}


type Transaction = {
  id: string;
  time: string;
  customerName: string;
  checkNumber: string;
  issuer: string;
  checkAmount: number;
  fee: number;
  deposited: string;
  createdAt: Timestamp;
  comment?: string;
  idNumber?: string;
  dob?: string;
  bankDeposited?: boolean;
}

export default function ReportsPage() {
  const [activeTab, setActiveTab] = useState('today');
  const [dateRange, setDateRange] = useState<{from: Date | undefined, to: Date | undefined}>({
    from: startOfDay(new Date()),
    to: endOfDay(new Date())
  });
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);

  const { user } = useUser();
  const firestore = useFirestore();
  const { toast } = useToast();

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<Transaction>(transactionsQuery);

  useEffect(() => {
    if (transactions) {
      handleGenerateReport('initial');
    }
  }, [transactions]);


  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value || 0);

  const handleGenerateReport = (source: 'button' | 'initial' = 'button') => {
    if (!transactions) {
      setFilteredTransactions([]);
      return;
    }
    
    let fromDate: Date | undefined, toDate: Date | undefined;
    let currentFiltered: Transaction[] = [];
    let isInitialLoad = source === 'initial';

    const todayStart = startOfDay(new Date());
    const todayEnd = endOfDay(new Date());

    if (isInitialLoad) {
      fromDate = todayStart;
      toDate = todayEnd;
    } else {
       switch(activeTab) {
        case 'today':
        case 'eod':
          fromDate = todayStart;
          toDate = todayEnd;
          break;
        case 'yesterday':
          fromDate = startOfDay(subDays(new Date(), 1));
          toDate = endOfDay(subDays(new Date(), 1));
          break;
        case 'custom':
          fromDate = dateRange.from ? startOfDay(dateRange.from) : undefined;
          toDate = dateRange.to ? endOfDay(dateRange.to) : undefined;
          break;
        default:
          currentFiltered = transactions;
      }
    }


    if(fromDate && toDate && activeTab !== 'management') {
      currentFiltered = transactions.filter(t => {
        const transactionDate = t.createdAt.toDate();
        return transactionDate >= fromDate! && transactionDate <= toDate!;
      });
    } else if (activeTab === 'management') {
        currentFiltered = transactions;
    } else if (!isInitialLoad) {
       currentFiltered = transactions;
    }

    if (isInitialLoad) {
      const todaysTransactions = transactions.filter(t => {
        const transactionDate = t.createdAt.toDate();
        return transactionDate >= todayStart && transactionDate <= todayEnd;
      });
      setFilteredTransactions(todaysTransactions.slice(0, 3));
    } else {
      setFilteredTransactions(currentFiltered);
      if (source === 'button') {
        toast({
            title: "Report Generated",
            description: `Found ${currentFiltered.length} transactions for the selected period.`,
            variant: 'success'
        })
      }
    }
  };
  
  const groupedTransactions = useMemo(() => {
    return filteredTransactions?.reduce((acc, transaction) => {
        const transactionDate = transaction.createdAt?.toDate() || new Date();
        const date = formatDateFns(transactionDate, 'yyyy-MM-dd');
        if (!acc[date]) {
        acc[date] = [];
        }
        acc[date].push(transaction);
        return acc;
    }, {} as Record<string, Transaction[]>);
  }, [filteredTransactions]);

  const sortedDates = groupedTransactions ? Object.keys(groupedTransactions).sort((a, b) => new Date(b).getTime() - new Date(a).getTime()) : [];

  const generatePdf = (action: 'view' | 'download') => {
    const doc = new jsPDF();
    const pageHeight = doc.internal.pageSize.height;
    let finalY = 20;

    // Report Header
    doc.setFontSize(22);
    doc.setFont('helvetica', 'bold');
    doc.text("Wrangler", doc.internal.pageSize.getWidth() / 2, 20, { align: 'center' });

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text("2163 E US HWY 377, Granbury, TX 76049", doc.internal.pageSize.getWidth() / 2, 27, { align: 'center' });
    doc.text("Check Cashing Details", doc.internal.pageSize.getWidth() / 2, 32, { align: 'center' });

    const getReportDate = () => {
        switch(activeTab) {
            case 'today':
            case 'eod':
                return formatDateFns(new Date(), 'MMMM do, yyyy');
            case 'yesterday':
                return formatDateFns(subDays(new Date(), 1), 'MMMM do, yyyy');
            case 'custom':
                if (dateRange.from && dateRange.to) {
                    if (formatDateFns(dateRange.from, 'yyyy-MM-dd') === formatDateFns(dateRange.to, 'yyyy-MM-dd')) {
                        return formatDateFns(dateRange.from, 'MMMM do, yyyy');
                    }
                    return `${formatDateFns(dateRange.from, 'MMM d, yyyy')} to ${formatDateFns(dateRange.to, 'MMM d, yyyy')}`;
                }
                return 'Custom Range';
            default:
                return formatDateFns(new Date(), 'MMMM do, yyyy');
        }
    }
    const reportDate = getReportDate();
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(`End of Day Report for ${reportDate}`, doc.internal.pageSize.getWidth() / 2, 40, { align: 'center' });
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text(`Date: ${reportDate}`, 14, 50);

    const tableData = filteredTransactions.map((t, index) => {
        const commentContent = t.comment || '';

        return [
            index + 1,
            t.time,
            t.customerName,
            t.checkNumber,
            t.issuer,
            formatCurrency(t.checkAmount),
            formatCurrency(t.fee),
            t.bankDeposited ? 'Yes' : '',
            commentContent.trim()
        ];
    });

    doc.autoTable({
        head: [['SN', 'Time', 'Customer Name', 'Check #', 'Issuer', 'Amount', 'Fee', 'Deposited', 'Comment']],
        body: tableData,
        startY: 55,
        headStyles: { fillColor: [0, 128, 128] }, // Teal color for header
        styles: { fontSize: 8, cellPadding: 2 },
        columnStyles: {
            0: { cellWidth: 8 }, // SN
            5: { halign: 'right' }, // Amount
            6: { halign: 'right' }, // Fee
        },
        didDrawPage: (data) => {
            finalY = data.cursor?.y || finalY;
        }
    });

    finalY = (doc as any).lastAutoTable.finalY || finalY;

    if (finalY > pageHeight - 80) {
        doc.addPage();
        finalY = 20;
    } else {
        finalY += 10;
    }

    // Summary Section
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text("Summary:", 14, finalY);
    finalY += 7;

    const totalChecksCashed = filteredTransactions.length;
    const totalCheckAmount = filteredTransactions.reduce((sum, t) => sum + t.checkAmount, 0);
    const totalCashingFee = filteredTransactions.reduce((sum, t) => sum + t.fee, 0);
    const totalAmountPaid = totalCheckAmount - totalCashingFee;
    const holdChecks = filteredTransactions.filter(t => (t as any).transactionType === 'Hold');
    const totalHoldChecks = holdChecks.length;
    const totalHoldAmount = holdChecks.reduce((sum, t) => sum + t.checkAmount, 0);
    const checksDeposited = filteredTransactions.filter(t => t.bankDeposited).length;
    const amountDeposited = filteredTransactions.filter(t => t.bankDeposited).reduce((sum, t) => sum + t.checkAmount, 0);
    const checksToDeposit = totalChecksCashed - checksDeposited;
    const amountToDeposit = totalCheckAmount - amountDeposited;

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');

    const summaryCol1X = 14;
    const summaryCol2X = 110;
    const summaryCol2ValX = doc.internal.pageSize.getWidth() - 14;

    doc.text(`Total Checks Cashed: ${totalChecksCashed}`, summaryCol1X, finalY);
    doc.text(`Total Cashing Fee:`, summaryCol2X, finalY);
    doc.text(`${formatCurrency(totalCashingFee)}`, summaryCol2ValX, finalY, { align: 'right' });
    finalY += 5;

    doc.text(`Total Check Amount: ${formatCurrency(totalCheckAmount)}`, summaryCol1X, finalY);
    doc.text(`Total Hold Checks:`, summaryCol2X, finalY);
    doc.text(`${totalHoldChecks} (${formatCurrency(totalHoldAmount)})`, summaryCol2ValX, finalY, { align: 'right' });
    finalY += 5;
    
    doc.text(`Total Amount Paid: ${formatCurrency(totalAmountPaid)}`, summaryCol1X, finalY);
    finalY += 10;

    doc.setFont('helvetica', 'bold');
    doc.text("--- DEPOSIT SUMMARY ---", summaryCol1X, finalY);
    finalY += 7;
    doc.setFont('helvetica', 'normal');
    
    doc.text(`Checks Deposited: ${checksDeposited}`, summaryCol1X, finalY);
    doc.text(`Amount Deposited:`, summaryCol2X, finalY);
    doc.text(`${formatCurrency(amountDeposited)}`, summaryCol2ValX, finalY, { align: 'right' });
    finalY += 5;

    doc.text(`Checks to Deposit: ${checksToDeposit}`, summaryCol1X, finalY);
    doc.text(`Amount to Deposit:`, summaryCol2X, finalY);
    doc.text(`${formatCurrency(amountToDeposit)}`, summaryCol2ValX, finalY, { align: 'right' });


    if (action === 'view') {
      doc.output('dataurlnewwindow');
    } else {
      doc.save('transaction-report.pdf');
    }
  };

  const generateExcel = () => {
    // Basic CSV generation
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Time,Customer Name,Check #,Issuer,Amount,Fee,Deposited,Comment\r\n";
    
    filteredTransactions.forEach(t => {
        const row = [
            t.time,
            `"${t.customerName}"`,
            t.checkNumber,
            `"${t.issuer}"`,
            t.checkAmount,
            t.fee,
            t.bankDeposited ? 'Yes' : '',
            `"${t.comment || ''}"`
        ].join(",");
        csvContent += row + "\r\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "transaction-report.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};


  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight">Report Generator</h1>
        <p className="text-muted-foreground">
          Select a report type and generate a report to view or export.
        </p>
      </header>

      <Card>
        <CardContent className="pt-6">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-transparent p-0 h-auto">
              <TabsTrigger value="eod" className={cn("text-muted-foreground data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none", activeTab === 'eod' && 'bg-primary/10 text-primary')}>EOD</TabsTrigger>
              <TabsTrigger value="today" className={cn("text-muted-foreground data-[state=active]:bg-primary data-[state=active]:text-primary-foreground data-[state=active]:shadow-none", activeTab === 'today' && 'bg-primary text-primary-foreground')}>Today</TabsTrigger>
              <TabsTrigger value="yesterday" className={cn("text-muted-foreground data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none", activeTab === 'yesterday' && 'bg-primary/10 text-primary')}>Yesterday</TabsTrigger>
              <TabsTrigger value="custom" className={cn("text-muted-foreground data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none", activeTab === 'custom' && 'bg-primary/10 text-primary')}>Custom Range</TabsTrigger>
              <TabsTrigger value="management" className={cn("text-muted-foreground data-[state=active]:bg-primary/10 data-[state=active]:text-primary data-[state=active]:shadow-none", activeTab === 'management' && 'bg-primary/10 text-primary')}>Management</TabsTrigger>
            </TabsList>
            <TabsContent value="custom" className="flex items-center gap-4">
              <DatePicker date={dateRange.from} setDate={(d) => setDateRange(prev => ({...prev, from: d}))} placeholder="Start date"/>
              <p>to</p>
              <DatePicker date={dateRange.to} setDate={(d) => setDateRange(prev => ({...prev, to: d}))} placeholder="End date" />
            </TabsContent>
             <TabsContent value="management">
              <p>Management reports will be displayed here.</p>
            </TabsContent>
          </Tabs>
          <div className="flex justify-end mt-4">
            <Button className="bg-teal-600 hover:bg-teal-700" onClick={() => handleGenerateReport('button')}>
              <Search className="mr-2 h-4 w-4" />
              Generate Report
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>Report Results</CardTitle>
              <CardDescription>
                {isLoading ? 'Loading transactions...' : `Displaying ${filteredTransactions.length || 0} transactions.`}
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => generatePdf('view')} disabled={filteredTransactions.length === 0}>
                <FileText className="mr-2 h-4 w-4" />
                View as PDF
              </Button>
              <Button variant="outline" className="bg-teal-600/10 text-teal-600 border-teal-600/20 hover:bg-teal-600/20" onClick={() => generatePdf('download')} disabled={filteredTransactions.length === 0}>
                <Download className="mr-2 h-4 w-4" />
                Export to PDF
              </Button>
              <Button variant="outline" className="bg-teal-600/10 text-teal-600 border-teal-600/20 hover:bg-teal-600/20" onClick={generateExcel} disabled={filteredTransactions.length === 0}>
                <Download className="mr-2 h-4 w-4" />
                Export to Excel
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
             <div className="space-y-4">
              <Skeleton className="h-10 w-1/3" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-10 w-1/3" />
              <Skeleton className="h-40 w-full" />
            </div>
          ) : sortedDates.length > 0 ? (
            sortedDates.map(date => (
              <div key={date} className="mb-8">
                <h3 className="text-lg font-semibold mb-4 bg-muted/50 p-2 rounded-md">{formatDateFns(parseISO(date), 'MMMM do, yyyy')}</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>SN</TableHead>
                      <TableHead>Time</TableHead>
                      <TableHead>Customer Name</TableHead>
                      <TableHead>Check #</TableHead>
                      <TableHead>Issuer</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead className="text-right">Fee</TableHead>
                      <TableHead>Deposited</TableHead>
                      <TableHead>Comment</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {groupedTransactions && groupedTransactions[date].map((transaction, index) => (
                      <TableRow key={transaction.id}>
                        <TableCell>{index + 1}</TableCell>
                        <TableCell>{transaction.time}</TableCell>
                        <TableCell className="font-medium">{transaction.customerName}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">{transaction.checkNumber}</Badge>
                        </TableCell>
                        <TableCell>{transaction.issuer}</TableCell>
                        <TableCell className="text-right font-medium">{formatCurrency(transaction.checkAmount)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(transaction.fee)}</TableCell>
                        <TableCell>{transaction.bankDeposited ? 'Yes' : ''}</TableCell>
                        <TableCell>{transaction.comment}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ))
          ) : (
             <div className="text-center py-10">
                <p className="text-muted-foreground">No transactions found for the selected report criteria.</p>
             </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
