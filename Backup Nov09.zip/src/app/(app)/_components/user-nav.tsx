
"use client"

import { LogOut } from "lucide-react"
import { signOut } from "firebase/auth";

import { useAuth } from "@/firebase";
import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar"

export function UserNav() {
  const auth = useAuth();
  
  const handleLogout = () => {
    signOut(auth);
  };

  return (
    <SidebarMenu>
      <SidebarMenuItem>
        <SidebarMenuButton onClick={handleLogout} className="w-full">
          <LogOut />
          Sign Out
        </SidebarMenuButton>
      </SidebarMenuItem>
    </SidebarMenu>
  )
}
