
'use client';

import { useMemo } from 'react';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, Timestamp } from 'firebase/firestore';
import { format as formatDateFns } from 'date-fns';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from '@/components/ui/skeleton';

export default function DAProsecutionPage() {
  const { user } = useUser();
  const firestore = useFirestore();

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<any>(transactionsQuery);

  const daProsecutionChecks = useMemo(() => {
    if (!transactions) return [];
    // A check is considered for DA Prosecution if it has a 'daStatus' of 'Submitted'
    return transactions.filter(t => t.daStatus === 'Submitted');
  }, [transactions]);


  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value || 0);

  const formatDate = (timestamp: Timestamp) => {
    if (!timestamp) return 'N/A';
    return formatDateFns(timestamp.toDate(), 'MM/dd/yyyy');
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>DA Prosecution</CardTitle>
        <CardDescription>
          Track and manage cases submitted for DA prosecution.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date Submitted</TableHead>
              <TableHead>Check #</TableHead>
              <TableHead>Payee</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead>Original Return Reason</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={6}>
                    <Skeleton className="h-10 w-full" />
                  </TableCell>
                </TableRow>
              ))
            ) : daProsecutionChecks.length > 0 ? (
              daProsecutionChecks.map((check) => (
              <TableRow key={check.id}>
                <TableCell>
                  {formatDate(check.createdAt)}
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">{check.checkNumber}</Badge>
                </TableCell>
                <TableCell className="font-medium">{check.customerName}</TableCell>
                <TableCell>
                  <Badge variant="outline">Submitted to DA</Badge>
                </TableCell>
                <TableCell className="text-right font-medium">
                  {formatCurrency(check.checkAmount)}
                </TableCell>
                <TableCell className="text-muted-foreground">{check.returnReason}</TableCell>
              </TableRow>
            ))
           ) : (
                <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                        No checks submitted for DA prosecution.
                    </TableCell>
                </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
