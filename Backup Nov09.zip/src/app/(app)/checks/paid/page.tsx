
'use client';

import { useMemo } from 'react';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, Timestamp } from 'firebase/firestore';
import { format as formatDateFns } from 'date-fns';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from '@/components/ui/skeleton';

export default function PaidChecksPage() {
  const { user } = useUser();
  const firestore = useFirestore();

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<any>(transactionsQuery);

  const paidChecks = useMemo(() => {
    if (!transactions) return [];
    // A check is considered "Paid" if it was returned BUT then successfully deposited.
    return transactions.filter(t => t.returnedFromBank && t.bankDeposited);
  }, [transactions]);


  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value || 0);

  const formatDate = (timestamp: Timestamp) => {
    if (!timestamp) return 'N/A';
    return formatDateFns(timestamp.toDate(), 'MM/dd/yyyy');
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Paid Checks</CardTitle>
        <CardDescription>
          View and manage checks that have been successfully paid after being returned.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date Paid</TableHead>
              <TableHead>Check #</TableHead>
              <TableHead>Payee</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead>Original Return Reason</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={6}>
                    <Skeleton className="h-10 w-full" />
                  </TableCell>
                </TableRow>
              ))
            ) : paidChecks.length > 0 ? (
              paidChecks.map((check) => (
              <TableRow key={check.id}>
                <TableCell>
                  {formatDate(check.createdAt)}
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">{check.checkNumber}</Badge>
                </TableCell>
                <TableCell className="font-medium">{check.customerName}</TableCell>
                <TableCell>
                  <Badge className="bg-green-500/20 text-green-400 border-green-500/20">Paid & Cleared</Badge>
                </TableCell>
                <TableCell className="text-right font-medium">
                  {formatCurrency(check.checkAmount)}
                </TableCell>
                <TableCell className="text-muted-foreground">{check.returnReason}</TableCell>
              </TableRow>
            ))
           ) : (
                <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                        No paid checks found.
                    </TableCell>
                </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
