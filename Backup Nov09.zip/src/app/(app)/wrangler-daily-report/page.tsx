
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function WranglerDailyReportPage() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Wrangler Daily Report</CardTitle>
        <CardDescription>
          Daily report for Wrangler.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <p>This page is under construction.</p>
      </CardContent>
    </Card>
  );
}
