
'use server';
/**
 * @fileOverview A flow to process a check and an optional ID document.
 * 
 * - processDocument - Extracts information from a check and an optional ID.
 * - ProcessDocumentInput - The input type for the processDocument function.
 * - ProcessDocumentOutput - The return type for the- processDocument function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ProcessDocumentInputSchema = z.object({
    checkImage: z.string().describe("A data URI of the check image, which must be a high-resolution photo of the front of a check. Expected format: 'data:<mimetype>;base64,<encoded_data>'."),
    idImage: z.string().nullable().describe("An optional data URI of a government-issued ID (like a driver's license). This is used to verify customer identity. Expected format: 'data:<mimetype>;base64,<encoded_data>'."),
});
export type ProcessDocumentInput = z.infer<typeof ProcessDocumentInputSchema>;

const ProcessDocumentOutputSchema = z.object({
    dateOfTransaction: z.string().optional().describe("The date written on the check, typically near the top right. Format as YYYY-MM-DD."),
    checkNumber: z.string().optional().describe('The unique number identifying the check, usually found in the top-right corner and on the MICR line at the bottom.'),
    customerName: z.string().optional().describe("The payee's name, as written in the 'Pay to the order of' line. If an ID is provided, prioritize the name from the ID as the definitive source."),
    address: z.string().optional().describe("The customer's address, extracted from either the check or the ID."),
    dob: z.string().optional().describe("The customer's date of birth, extracted from the ID. Format as YYYY-MM-DD."),
    idNumber: z.string().optional().describe("The customer's ID number, from a driver's license or other government ID."),
    issuingAuthority: z.string().optional().describe("The authority that issued the ID, e.g., 'State of Texas'."),
    customerPhone: z.string().optional().describe("The customer's phone number, extracted from either the check or the ID if available."),
    customerSsn: z.string().optional().describe("The customer's Social Security Number (SSN). Extract this ONLY if it is clearly visible on the provided ID document."),
    checkIssuerName: z.string().optional().describe('The name of the person or entity that wrote the check (the payer), usually found at the top left.'),
    checkIssuerAddress: z.string().optional().describe("The address of the check issuer, typically located below the issuer's name."),
    checkIssuerPhone: z.string().optional().describe("The phone number of the check issuer, if present on the check."),
    checkAmount: z.string().optional().describe('The numerical value of the check, as written in the box (e.g., "$123.45"). Extract only the number.'),
    checkAmountWritten: z.string().optional().describe("The written-out, legal amount of the check."),
    accountNumber: z.string().optional().describe('The bank account number, located on the MICR line at the bottom of the check.'),
    routingNumber: z.string().optional().describe('The bank routing number, found on the MICR line at the bottom of the check.'),
    isSigned: z.boolean().optional().describe('A boolean (true/false) indicating whether a signature is present in the signature line at the bottom right of the check.'),
    bankName: z.string().optional().describe('The name of the financial institution that issued the check, usually printed on the check.'),
    documentType: z.string().optional().describe("The type of document if it is an ID (e.g., Driver's License, Passport)."),
    expirationDate: z.string().optional().describe("The expiration date from the ID. Format as YYYY-MM-DD."),
    photoPresence: z.boolean().optional().describe("Whether a photo is present on the ID (Yes/No).")
});
export type ProcessDocumentOutput = z.infer<typeof ProcessDocumentOutputSchema>;

const documentProcessingPrompt = ai.definePrompt({
    name: 'documentProcessingPrompt',
    input: { schema: ProcessDocumentInputSchema },
    output: { schema: ProcessDocumentOutputSchema },
    prompt: `Analyze the provided image(s) to extract specific, structured information. The image(s) are expected to be either a financial check or a government-issued identification (ID).

**Instructions:**
1.  **Classify** the image type (Check or ID).
2.  **Extract all fields** for the identified type. If the image is a check, prioritize clear, human-readable data (e.g., Payee Name, Amount). If it's an ID, prioritize primary identifiers (e.g., Full Name, DOB, Document Number).
3.  **Format the output as a single, clean JSON object.** If a required field is not found or is unclear, use the value 'N/A'.

Check Image: {{media url=checkImage}}
{{#if idImage}}
ID Image: {{media url=idImage}}
{{/if}}
`
});

const processDocumentFlow = ai.defineFlow(
    {
        name: 'processDocumentFlow',
        inputSchema: ProcessDocumentInputSchema,
        outputSchema: ProcessDocumentOutputSchema,
    },
    async (input) => {
        const { output } = await documentProcessingPrompt(input);
        return output!;
    }
);


export async function processDocument(input: ProcessDocumentInput): Promise<ProcessDocumentOutput> {
    return processDocumentFlow(input);
}
