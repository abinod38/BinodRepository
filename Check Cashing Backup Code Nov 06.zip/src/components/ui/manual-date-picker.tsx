'use client';

import * as React from 'react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { isValid, parse } from 'date-fns';

type ManualDatePickerProps = {
  date?: Date;
  setDate: (date: Date | undefined) => void;
  className?: string;
};

export function ManualDatePicker({ date, setDate, className }: ManualDatePickerProps) {
  const [day, setDay] = React.useState<string>(date ? String(date.getDate()) : '');
  const [month, setMonth] = React.useState<string>(date ? String(date.getMonth() + 1) : '');
  const [year, setYear] = React.useState<string>(date ? String(date.getFullYear()) : '');

  React.useEffect(() => {
    setDay(date ? String(date.getDate()) : '');
    setMonth(date ? String(date.getMonth() + 1) : '');
    setYear(date ? String(date.getFullYear()) : '');
  }, [date]);

  const handleDateChange = (newDay: string, newMonth: string, newYear: string) => {
    const dayInt = parseInt(newDay, 10);
    const monthInt = parseInt(newMonth, 10);
    const yearInt = parseInt(newYear, 10);

    if (
      newDay.length > 0 && newMonth.length > 0 && newYear.length === 4 &&
      !isNaN(dayInt) && !isNaN(monthInt) && !isNaN(yearInt)
    ) {
      const dateStr = `${yearInt}-${String(monthInt).padStart(2, '0')}-${String(dayInt).padStart(2, '0')}`;
      const parsedDate = parse(dateStr, 'yyyy-MM-dd', new Date());

      if (isValid(parsedDate)) {
        setDate(parsedDate);
      } else {
        setDate(undefined);
      }
    } else {
      setDate(undefined);
    }
  };

  const handleDayChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    if (value.length <= 2) {
      setDay(value);
      handleDateChange(value, month, year);
    }
  };

  const handleMonthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
     if (value.length <= 2) {
      setMonth(value);
      handleDateChange(day, value, year);
    }
  };

  const handleYearChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    if (value.length <= 4) {
      setYear(value);
      handleDateChange(day, month, value);
    }
  };

  return (
    <div className={cn('flex gap-2', className)}>
      <Input
        type="text"
        placeholder="DD"
        value={day}
        onChange={handleDayChange}
        maxLength={2}
        className="w-1/3 text-center"
      />
      <Input
        type="text"
        placeholder="MM"
        value={month}
        onChange={handleMonthChange}
        maxLength={2}
        className="w-1/3 text-center"
      />
      <Input
        type="text"
        placeholder="YYYY"
        value={year}
        onChange={handleYearChange}
        maxLength={4}
        className="w-1/3 text-center"
      />
    </div>
  );
}
