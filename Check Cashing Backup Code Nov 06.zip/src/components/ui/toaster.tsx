"use client"

import { useToast } from "@/hooks/use-toast"
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast"

export function Toaster() {
  const { toasts } = useToast()

  const positions = {
    'top-left': [],
    'top-right': [],
    'bottom-left': [],
    'bottom-right': [],
    'top-center': [],
    'bottom-center': [],
  };

  toasts.forEach(toast => {
    const pos = toast.position || 'top-center';
    if (!positions[pos]) {
      positions['top-center'].push(toast);
    } else {
      positions[pos].push(toast);
    }
  });


  return (
    <ToastProvider>
       {Object.entries(positions).map(([pos, toastGroup]) => (
         <ToastViewport key={pos} position={pos as any}>
            {toastGroup.map(function ({ id, title, description, action, ...props }) {
              return (
                <Toast key={id} {...props}>
                  <div className="grid gap-1">
                    {title && <ToastTitle>{title}</ToastTitle>}
                    {description && (
                      <ToastDescription>{description}</ToastDescription>
                    )}
                  </div>
                  {action}
                  <ToastClose />
                </Toast>
              )
            })}
         </ToastViewport>
      ))}
    </ToastProvider>
  )
}
