export const firebaseConfig = {
  "projectId": "studio-990146858-94237",
  "appId": "1:134176964927:web:ba25c8c472a81f75fd938a",
  "apiKey": "AIzaSyDoBSQFurUY9HbCguZ9m2VDUvrS9wow8x0",
  "authDomain": "studio-990146858-94237.firebaseapp.com",
  "storageBucket": "studio-990146858-94237.appspot.com",
  "measurementId": "",
  "messagingSenderId": "134176964927"
};
