
"use client"

import {
  AlertTriangle,
  ArrowRight,
  Ban,
  Calendar,
  CheckCircle2,
  ChevronRight,
  CircleDollarSign,
  FileBarChart,
  FileCheck,
  FileX,
  Landmark,
  LineChart,
  MinusCircle,
  PauseCircle,
  Repeat2,
  TrendingUp,
} from "lucide-react"

import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts"

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Separator } from "@/components/ui/separator";

const dailyVolume = [
  { date: "Oct 5", volume: 10000 },
  { date: "Oct 6", volume: 15000 },
  { date: "Oct 7", volume: 12000 },
  { date: "Oct 8", volume: 38000 },
  { date: "Oct 9", volume: 65000 },
  { date: "Oct 10", volume: 40000 },
  { date: "Oct 11", volume: 22000 },
  { date: "Oct 12", volume: 32000 },
  { date: "Oct 13", volume: 25000 },
  { date: "Oct 14", volume: 18000 },
  { date: "Oct 15", volume: 35000 },
  { date: "Oct 16", volume: 98000 },
  { date: "Oct 17", volume: 50000 },
  { date: "Oct 18", volume: 20000 },
  { date: "Oct 19", volume: 31000 },
  { date: "Oct 20", volume: 15000 },
  { date: "Oct 21", volume: 21000 },
  { date: "Oct 22", volume: 18000 },
  { date: "Oct 23", volume: 24000 },
  { date: "Oct 24", volume: 82000 },
  { date: "Oct 25", volume: 20000 },
  { date: "Oct 26", volume: 19000 },
  { date: "Oct 27", volume: 22000 },
  { date: "Oct 28", volume: 0 }, // Assuming no data for this day
  { date: "Oct 29", volume: 0 }, // Assuming no data for this day
  { date: "Oct 30", volume: 14437.25 },
  { date: "Oct 31", volume: 48000 },
  { date: "Nov 1", volume: 28000 },
  { date: "Nov 2", volume: 25000 },
  { date: "Nov 3", volume: 18000 },
];

const formatCurrency = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(value)

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Here's a summary of your check cashing activity.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-6">
          {/* Today's Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Today's Activity
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center gap-4">
                <div className="text-5xl font-bold text-primary">#</div>
                <div>
                  <p className="text-sm text-muted-foreground">Checks Cashed Today</p>
                  <p className="text-3xl font-bold">3</p>
                  <p className="text-xs text-muted-foreground">2426 all time</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Today's Financials</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Total Check Amount</span>
                    <span className="font-medium">{formatCurrency(496.01)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Cashed Out</span>
                    <span className="font-medium text-red-400">{formatCurrency(485.00)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Cashing Fee</span>
                    <span className="font-medium text-green-400">{formatCurrency(11.01)}</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="flex items-center gap-2"><Landmark className="h-4 w-4 text-muted-foreground" /> Deposited Checks</span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Deposited Amount</span>
                    <span className="font-medium">{formatCurrency(0.00)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Financial Summary */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <LineChart className="h-5 w-5" />
                Financial Summary
              </CardTitle>
              <Select defaultValue="today">
                <SelectTrigger className="w-[120px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="week">This Week</SelectItem>
                  <SelectItem value="month">This Month</SelectItem>
                </SelectContent>
              </Select>
            </CardHeader>
            <CardContent>
                <div className="space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Total Checks Cashed</span>
                    <span className="font-medium">3</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Check Amount</span>
                    <span className="font-medium">{formatCurrency(496.01)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Cashed Out</span>
                    <span className="font-medium text-red-400">{formatCurrency(485.00)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total Cashing Fee</span>
                    <span className="font-medium text-green-400">{formatCurrency(11.01)}</span>
                  </div>
                  <div className="flex justify-between items-center mt-2">
                    <span className="flex items-center gap-2"><Landmark className="h-4 w-4 text-muted-foreground" /> Deposited Checks</span>
                    <span className="font-medium">0</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Deposited Amount</span>
                    <span className="font-medium">{formatCurrency(0.00)}</span>
                  </div>
                </div>
            </CardContent>
          </Card>

          {/* Daily Volume */}
          <Card>
            <CardHeader>
              <CardTitle>Daily Volume (Last 30 Days)</CardTitle>
              <CardDescription>
                Total check amounts cashed each day.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  volume: {
                    label: "Volume",
                    color: "hsl(var(--primary))",
                  },
                }}
                className="h-[300px] w-full"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dailyVolume} margin={{ top: 20, right: 20, left: -10, bottom: 0 }}>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickLine={false} axisLine={false} tickMargin={10}/>
                    <YAxis tickLine={false} axisLine={false} tickFormatter={(value) => `$${value / 1000}k`}/>
                    <Tooltip
                      cursor={{ fill: "hsl(var(--card))" }}
                      content={<ChartTooltipContent 
                        formatter={(value, name) => (
                           <div className="flex flex-col">
                             <span>{name}: {formatCurrency(Number(value))}</span>
                           </div>
                        )}
                        labelFormatter={(label) => `Date: ${label}`}
                      />}
                    />
                    <Bar dataKey="volume" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Area */}
        <div className="space-y-6">
          {/* Check Status Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Check Status Summary (All Time)</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <Card className="bg-green-500/10 border-green-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <CheckCircle2 className="h-6 w-6 text-green-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="text-2xl font-bold">2389</p>
                  <p className="text-sm text-muted-foreground">Good Checks</p>
                </CardContent>
              </Card>
               <Card className="bg-yellow-500/10 border-yellow-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <AlertTriangle className="h-6 w-6 text-yellow-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="text-2xl font-bold">0</p>
                  <p className="text-sm text-muted-foreground">Precaution</p>
                </CardContent>
              </Card>
               <Card className="bg-red-500/10 border-red-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <Ban className="h-6 w-6 text-red-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="text-2xl font-bold">10</p>
                  <p className="text-sm text-muted-foreground">Bad Checks</p>
                </CardContent>
              </Card>
              <Card className="bg-blue-500/10 border-blue-500/30">
                <CardHeader className="p-4 flex items-center justify-between">
                   <Repeat2 className="h-6 w-6 text-blue-500"/>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="text-2xl font-bold">2</p>
                  <p className="text-sm text-muted-foreground">Frequent Returns</p>
                </CardContent>
              </Card>
            </CardContent>
          </Card>

          {/* CTR Reports */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><AlertTriangle className="text-yellow-500"/>CTR Reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileBarChart className="h-5 w-5 text-yellow-500"/>
                  <div>
                    <p className="font-medium">CTR Needed</p>
                    <p className="text-xs text-muted-foreground">Transactions over $10k</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold">1</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground"/>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileCheck className="h-5 w-5 text-green-500"/>
                  <div>
                    <p className="font-medium">CTR Filed</p>
                    <p className="text-xs text-muted-foreground">Filed reports history</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-bold">9</span>
                   <ChevronRight className="h-4 w-4 text-muted-foreground"/>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <FileX className="h-5 w-5 text-red-500"/>
                  <div>
                    <p className="font-medium">CTR Ignored</p>
                    <p className="text-xs text-muted-foreground">Manually ignored reports</p>
                  </div>
                </div>
                 <div className="flex items-center gap-2">
                  <span className="font-bold">7</span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground"/>
                </div>
              </div>
            </CardContent>
          </Card>

           {/* Returned Checks */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2"><TrendingUp />Returned Checks</CardTitle>
              <ArrowRight className="h-4 w-4 text-muted-foreground cursor-pointer"/>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">9</p>
              <p className="text-sm text-muted-foreground">checks pending payment</p>
              <Separator className="my-4"/>
              <div className="text-sm">
                <div className="flex justify-between">
                  <span>Total Receivable:</span>
                  <span className="font-medium text-red-400">{formatCurrency(19330.40)}</span>
                </div>
                <div className="flex justify-between mt-2">
                  <span>Checks with DA:</span>
                  <span className="font-medium">1</span>
                </div>
                <div className="flex justify-between">
                  <span>Amount with DA:</span>
                  <span className="font-medium">{formatCurrency(7300.00)}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* On-Hold Financials */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2"><PauseCircle />On-Hold Financials</CardTitle>
              <ArrowRight className="h-4 w-4 text-muted-foreground cursor-pointer"/>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Owed to Customers</p>
                <p className="text-2xl font-bold text-green-400">{formatCurrency(2450.00)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Owed by Customers (Buybacks)</p>
                <p className="text-2xl font-bold text-yellow-400">{formatCurrency(1500.00)}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
