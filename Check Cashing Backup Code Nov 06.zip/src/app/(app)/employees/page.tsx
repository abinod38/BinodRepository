
'use client';

import { useState, useMemo } from 'react';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, doc } from 'firebase/firestore';
import { PlusCircle, Edit, Trash2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { format, isValid } from 'date-fns';

import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { addDocumentNonBlocking, deleteDocumentNonBlocking, setDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { ManualDatePicker } from '@/components/ui/manual-date-picker';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const employeeFormSchema = z.object({
  name: z.string().min(1, 'Employee name is required'),
  phone: z.string().optional(),
  email: z.string().email('Invalid email address').optional().or(z.literal('')),
  address: z.string().optional(),
  ssn: z.string().optional(),
  dateOfBirth: z.date().optional(),
  dateOfHire: z.date().optional(),
  payRate: z.coerce.number().optional(),
  status: z.boolean().default(true),
});

type EmployeeFormValues = z.infer<typeof employeeFormSchema>;

type Employee = Omit<EmployeeFormValues, 'dateOfBirth' | 'dateOfHire'> & {
  id: string;
  dateOfBirth?: { seconds: number; nanoseconds: number; } | string;
  dateOfHire?: { seconds: number; nanoseconds: number; } | string;
};

export default function EmployeesPage() {
  const { toast } = useToast();
  const { user } = useUser();
  const firestore = useFirestore();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [employeeToDelete, setEmployeeToDelete] = useState<Employee | null>(null);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'passive'>('all');


  const employeesQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collection(firestore, `users/${user.uid}/employees`),
      orderBy('name')
    );
  }, [user, firestore]);

  const { data: employees, isLoading } = useCollection<Employee>(employeesQuery);

  const filteredEmployees = useMemo(() => {
    if (!employees) return [];
    if (statusFilter === 'all') return employees;
    const isActive = statusFilter === 'active';
    return employees.filter(employee => employee.status === isActive);
  }, [employees, statusFilter]);

  const form = useForm<EmployeeFormValues>({
    resolver: zodResolver(employeeFormSchema),
    defaultValues: {
      name: '',
      phone: '',
      email: '',
      address: '',
      ssn: '',
      dateOfBirth: undefined,
      dateOfHire: undefined,
      payRate: 0,
      status: true,
    },
  });

  const handleDialogOpen = (employee: Employee | null = null) => {
    setEditingEmployee(employee);
    if (employee) {
      const parseDate = (date: any) => {
        if (!date) return undefined;
        const d = typeof date === 'string' ? new Date(date) : new Date(date.seconds * 1000);
        return isValid(d) ? d : undefined;
      }
      form.reset({
        ...employee,
        dateOfBirth: parseDate(employee.dateOfBirth),
        dateOfHire: parseDate(employee.dateOfHire),
        status: employee.status === undefined ? true : employee.status, // Default to active if not set
      });
    } else {
      form.reset({
        name: '',
        phone: '',
        email: '',
        address: '',
        ssn: '',
        dateOfBirth: undefined,
        dateOfHire: undefined,
        payRate: 0,
        status: true,
      });
    }
    setIsDialogOpen(true);
  };

  const onSubmit = (data: EmployeeFormValues) => {
    if (!user) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'You must be logged in to manage employees.',
      });
      return;
    }
    
    const employeeData = { 
      ...data, 
      dateOfBirth: data.dateOfBirth ? data.dateOfBirth.toISOString() : null,
      dateOfHire: data.dateOfHire ? data.dateOfHire.toISOString() : null,
    };

    if (editingEmployee) {
      const docRef = doc(firestore, `users/${user.uid}/employees`, editingEmployee.id);
      setDocumentNonBlocking(docRef, employeeData, { merge: true });
      toast({
        title: 'Employee Updated',
        description: `${data.name} has been successfully updated.`,
      });
    } else {
      const employeesColRef = collection(firestore, `users/${user.uid}/employees`);
      addDocumentNonBlocking(employeesColRef, employeeData);
      toast({
        title: 'Employee Added',
        description: `${data.name} has been successfully added.`,
      });
    }
    
    form.reset();
    setIsDialogOpen(false);
    setEditingEmployee(null);
  };
  
  const handleDeleteEmployee = () => {
    if (!user || !employeeToDelete) return;

    const docRef = doc(firestore, `users/${user.uid}/employees`, employeeToDelete.id);
    deleteDocumentNonBlocking(docRef);

    toast({
      title: "Employee Deleted",
      description: `The employee ${employeeToDelete.name} has been deleted.`,
    });
    setEmployeeToDelete(null);
  };

  const formatDate = (date: any) => {
    if (!date) return '';
    const d = new Date(typeof date === 'string' ? date : date.seconds * 1000);
    if (!isValid(d)) return 'N/A';
    return format(d, 'MM/dd/yyyy');
  }

  const formatCurrency = (value: number | undefined) => {
    if (value === undefined) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between md:items-center">
            <div>
                <CardTitle>Employee Details</CardTitle>
                <CardDescription>A list of all your employees.</CardDescription>
            </div>
            <Button onClick={() => handleDialogOpen()}>
                <PlusCircle className="mr-2 h-4 w-4" />
                Add New Employee
            </Button>
        </div>
         <div className="flex items-center gap-2 pt-4">
          <span className="text-sm font-medium">Filter by status:</span>
          <Button
            variant={statusFilter === 'all' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setStatusFilter('all')}
            className={statusFilter === 'all' ? 'bg-primary/10 text-primary' : ''}
          >
            All
          </Button>
          <Button
            variant={statusFilter === 'active' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setStatusFilter('active')}
             className={statusFilter === 'active' ? 'bg-primary/10 text-primary' : ''}
          >
            Active
          </Button>
          <Button
            variant={statusFilter === 'passive' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => setStatusFilter('passive')}
             className={statusFilter === 'passive' ? 'bg-primary/10 text-primary' : ''}
          >
            Passive
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>SN</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Address</TableHead>
              <TableHead>SSN</TableHead>
              <TableHead>DOB</TableHead>
              <TableHead>Hire Date</TableHead>
              <TableHead>Pay Rate</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
             {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell colSpan={11}>
                      <Skeleton className="h-10 w-full" />
                    </TableCell>
                  </TableRow>
                ))
              ) : filteredEmployees && filteredEmployees.length > 0 ? (
                filteredEmployees.map((employee, index) => (
                  <TableRow key={employee.id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell className="font-medium">{employee.name}</TableCell>
                    <TableCell>{employee.phone}</TableCell>
                    <TableCell>{employee.email}</TableCell>
                    <TableCell>{employee.address}</TableCell>
                    <TableCell>{employee.ssn}</TableCell>
                    <TableCell>{formatDate(employee.dateOfBirth)}</TableCell>
                    <TableCell>{formatDate(employee.dateOfHire)}</TableCell>
                    <TableCell>{formatCurrency(employee.payRate)}</TableCell>
                    <TableCell>
                      <Badge variant={employee.status ? 'default' : 'destructive'}>
                        {employee.status ? 'Active' : 'Passive'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => handleDialogOpen(employee)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setEmployeeToDelete(employee)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
             ) : (
                <TableRow>
                  <TableCell colSpan={11} className="h-24 text-center">
                    No employees found. Add a new employee to get started.
                  </TableCell>
                </TableRow>
             )}
          </TableBody>
        </Table>
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingEmployee ? 'Edit Employee' : 'Add New Employee'}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., John Doe" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., (123) 456-7890" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., john.doe@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 123 Main St, Anytown, USA" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                 <FormField
                  control={form.control}
                  name="ssn"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SSN</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., XXX-XX-XXXX" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="payRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Pay Rate ($/hr)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="e.g., 15.50" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="dateOfBirth"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Birth</FormLabel>
                      <ManualDatePicker date={field.value} setDate={field.onChange} />
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="dateOfHire"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Hire</FormLabel>
                      <ManualDatePicker date={field.value} setDate={field.onChange} />
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                    <div className="space-y-0.5">
                      <FormLabel>Status</FormLabel>
                      <FormMessage />
                    </div>
                    <FormControl>
                       <div className='flex items-center space-x-2'>
                        <span className={cn("text-muted-foreground", !field.value && 'font-medium text-foreground')}>Passive</span>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                        <span className={cn("text-muted-foreground", field.value && 'font-medium text-foreground')}>Active</span>
                       </div>
                    </FormControl>
                  </FormItem>
                )}
              />
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" variant="secondary">Cancel</Button>
                </DialogClose>
                <Button type="submit">{editingEmployee ? 'Save Changes' : 'Add Employee'}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
       <AlertDialog open={!!employeeToDelete} onOpenChange={(open) => !open && setEmployeeToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the employee
              <span className="font-semibold"> {employeeToDelete?.name}</span>.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteEmployee}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
