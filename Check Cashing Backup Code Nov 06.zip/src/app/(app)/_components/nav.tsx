
"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import {
  LayoutDashboard,
  CheckSquare,
  PlusCircle,
  FileClock,
  FileX2,
  AreaChart,
  Users,
  ChevronDown,
  History,
  User,
  Gavel,
  CircleDollarSign,
  Store,
  Contact,
  CalendarClock,
  CalendarDays,
  ScanLine,
  LogOut,
  StickyNote,
  Briefcase,
  Award,
  Settings,
  Landmark,
} from "lucide-react"

import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  useSidebar,
} from "@/components/ui/sidebar"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"

const menuItems = [
  {
    href: "/transactions/new",
    icon: PlusCircle,
    label: "New Transaction",
  },
  {
    href: "/dashboard",
    icon: LayoutDashboard,
    label: "Dashboard",
  },
  {
    href: "/transactions",
    icon: History,
    label: "Transaction History",
  },
  {
    href: "/customers",
    icon: Users,
    label: "Profile Customers",
  },
  {
    label: "Returned Checks",
    icon: FileX2,
    isGroup: true,
    children: [
      {
        href: "/checks/returned",
        icon: FileX2,
        label: "Returned",
      },
      {
        href: "/da-prosecution",
        icon: Gavel,
        label: "DA Prosecution",
      },
      {
        href: "/checks/paid",
        icon: CircleDollarSign,
        label: "Paid Checks",
      },
    ],
  },
  {
    href: "/checks/hold",
    icon: FileClock,
    label: "Checks On Hold / Buyback",
  },
  {
    href: "/ctr-report",
    icon: AreaChart,
    label: "CTR Report",
  },
  {
    href: "/reports",
    icon: AreaChart,
    label: "Reports",
  },
  {
    href: "/bank-deposit",
    icon: Landmark,
    label: "Bank Deposit",
  },
  {
    href: "/deposit-history",
    icon: History,
    label: "Deposit History",
  },
  {
    href: "/management",
    icon: Briefcase,
    label: "Management",
  },
  {
    href: "/licenses",
    icon: Award,
    label: "Licenses",
  },
  {
    href: "/vendors",
    icon: Store,
    label: "Vendors",
  },
  {
    href: "/employees",
    icon: Contact,
    label: "Employee Details",
  },
  {
    href: "/due-date",
    icon: CalendarClock,
    label: "Due Date",
  },
  {
    href: "/roster-schedule",
    icon: CalendarDays,
    label: "Roster / Schedule",
  },
  {
    label: "Notes",
    icon: StickyNote,
    isGroup: true,
    children: [
      {
        href: "/for-employee",
        icon: Contact,
        label: "For Employee",
      },
    ],
  },
  {
    href: "/settings",
    icon: Settings,
    label: "Settings",
  },
]

export function Nav() {
  const pathname = usePathname()
  const { setOpenMobile } = useSidebar()

  const isActive = (href: string, isExact = true) => {
    return isExact ? pathname === href : pathname.startsWith(href)
  }

  const handleLinkClick = () => {
    setOpenMobile(false)
  }

  return (
    <SidebarMenu>
      {menuItems.map((item) =>
        item.isGroup && item.children ? (
          <Collapsible key={item.label} className="w-full" defaultOpen={item.children.some(child => isActive(child.href, false))}>
             <SidebarMenuItem>
              <CollapsibleTrigger asChild>
                <SidebarMenuButton
                  className="w-full justify-between"
                  isActive={item.children.some(child => isActive(child.href))}
                  tooltip={item.label}
                  asChild={false}
                >
                  <div className="flex items-center gap-2">
                    <item.icon />
                    <span>{item.label}</span>
                  </div>
                  <ChevronDown className="h-4 w-4 shrink-0 transition-transform duration-200 group-data-[state=open]:rotate-180" />
                </SidebarMenuButton>
              </CollapsibleTrigger>
            </SidebarMenuItem>
            <CollapsibleContent>
                <SidebarMenuSub>
                {item.children.map((child) => (
                    <SidebarMenuItem key={child.href}>
                    <SidebarMenuSubButton asChild isActive={isActive(child.href)}>
                        <Link href={child.href} onClick={handleLinkClick}>
                        <child.icon />
                        <span>{child.label}</span>
                        </Link>
                    </SidebarMenuSubButton>
                    </SidebarMenuItem>
                ))}
                </SidebarMenuSub>
            </CollapsibleContent>
          </Collapsible>
        ) : (
          <SidebarMenuItem key={item.href}>
            <SidebarMenuButton asChild isActive={isActive(item.href!)}>
              <Link href={item.href!} onClick={handleLinkClick}>
                <item.icon />
                <span>{item.label}</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        )
      )}
    </SidebarMenu>
  )
}
