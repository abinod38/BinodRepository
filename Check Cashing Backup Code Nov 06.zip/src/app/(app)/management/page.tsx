
'use client';

import { useState, useMemo, useEffect } from 'react';
import {
  BarChart,
  TrendingUp,
  AlertTriangle,
  Users,
  Building,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { topCustomers, topIssuers } from '@/lib/data';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, Timestamp } from 'firebase/firestore';
import { Skeleton } from '@/components/ui/skeleton';


export default function ManagementPage() {
  const { user } = useUser();
  const firestore = useFirestore();

  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState<number>(new Date().getMonth());

  const transactionsQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<any>(transactionsQuery);

  const filteredTransactions = useMemo(() => {
    if (!transactions) return [];
    return transactions.filter(t => {
      if (t.createdAt instanceof Timestamp) {
        const transactionDate = t.createdAt.toDate();
        return transactionDate.getFullYear() === selectedYear && transactionDate.getMonth() === selectedMonth;
      }
      return false;
    });
  }, [transactions, selectedYear, selectedMonth]);
  
  const stats = useMemo(() => {
    const checksCashed = filteredTransactions.length;
    const totalVolume = filteredTransactions.reduce((sum, t) => sum + (t.checkAmount || 0), 0);
    const totalFees = filteredTransactions.reduce((sum, t) => sum + (t.fee || 0), 0);
    const netLossFromReturns = filteredTransactions
      .filter(t => t.returnedFromBank)
      .reduce((sum, t) => sum + (t.checkAmount || 0), 0);
    const totalProfit = totalFees - netLossFromReturns;

    return {
      checksCashed,
      totalVolume,
      totalFees,
      netLossFromReturns,
      totalProfit,
    };
  }, [filteredTransactions]);


  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);

  const years = Array.from({ length: 100 }, (_, i) => 2000 + i);
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August',
    'September', 'October', 'November', 'December'
  ];

  const statCards = [
    {
      label: 'Checks Cashed',
      value: stats.checksCashed.toString(),
      icon: <BarChart className="h-6 w-6 text-muted-foreground" />,
    },
    {
      label: 'Total Volume',
      value: formatCurrency(stats.totalVolume),
      icon: <TrendingUp className="h-6 w-6 text-muted-foreground" />,
    },
    {
      label: 'Total Fees',
      value: formatCurrency(stats.totalFees),
      icon: <TrendingUp className="h-6 w-6 text-muted-foreground" />,
    },
    {
      label: 'Net Loss from Returns',
      value: formatCurrency(stats.netLossFromReturns),
      icon: <AlertTriangle className="h-6 w-6 text-red-500" />,
      valueColor: 'text-red-500',
    },
    {
      label: 'Total Profit',
      value: formatCurrency(stats.totalProfit),
      icon: <TrendingUp className="h-6 w-6 text-muted-foreground" />,
    },
  ];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold tracking-tight">Management Report</h1>
        <p className="text-muted-foreground">
          A high-level overview of business performance for a selected period.
        </p>
      </header>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
            <CardTitle>Monthly Snapshot</CardTitle>
            <div className="flex items-center gap-2">
              <Select value={selectedMonth.toString()} onValueChange={(value) => setSelectedMonth(parseInt(value))}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select Month" />
                </SelectTrigger>
                <SelectContent>
                  {months.map((month, index) => (
                    <SelectItem key={index} value={index.toString()}>{month}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedYear.toString()} onValueChange={(value) => setSelectedYear(parseInt(value))}>
                <SelectTrigger className="w-[120px]">
                  <SelectValue placeholder="Select Year" />
                </SelectTrigger>
                <SelectContent>
                  {years.map(year => (
                    <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {isLoading ? (
             Array.from({ length: 5 }).map((_, i) => (
                <Card key={i} className="p-4 space-y-2">
                  <Skeleton className="h-6 w-24" />
                  <Skeleton className="h-8 w-32" />
                </Card>
             ))
          ) : (
            statCards.map((stat) => (
              <Card key={stat.label} className="p-4">
                <div className="flex items-center gap-4">
                  {stat.icon}
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p
                      className={`text-2xl font-bold ${stat.valueColor || ''}`}
                    >
                      {stat.value}
                    </p>
                  </div>
                </div>
              </Card>
            ))
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="text-muted-foreground" />
              Top 10 Customers
            </CardTitle>
            <p className="text-sm text-muted-foreground">By total volume for the selected period.</p>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead className="text-center">Checks</TableHead>
                  <TableHead className="text-right">Volume</TableHead>
                  <TableHead className="text-right">Fees</TableHead>
                  <TableHead className="text-right">Bad</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topCustomers.map((customer, index) => (
                  <TableRow key={customer.id}>
                    <TableCell>{index + 1}.</TableCell>
                    <TableCell className="font-medium">
                      {customer.name}
                    </TableCell>
                    <TableCell className="text-center">{customer.checks}</TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(customer.volume)}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(customer.fees)}
                    </TableCell>
                    <TableCell className="text-right">{customer.bad}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="text-muted-foreground" />
              Top 10 Issuers
            </CardTitle>
            <p className="text-sm text-muted-foreground">By total volume for the selected period.</p>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>Issuer</TableHead>
                  <TableHead className="text-center">Checks</TableHead>
                  <TableHead className="text-right">Volume</TableHead>
                  <TableHead className="text-right">Fees</TableHead>
                  <TableHead className="text-right">Bad</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topIssuers.map((issuer, index) => (
                  <TableRow key={issuer.id}>
                    <TableCell>{index + 1}.</TableCell>
                    <TableCell className="font-medium">{issuer.name}</TableCell>
                    <TableCell className="text-center">{issuer.checks}</TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(issuer.volume)}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(issuer.fees)}
                    </TableCell>
                    <TableCell className="text-right">{issuer.bad}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
