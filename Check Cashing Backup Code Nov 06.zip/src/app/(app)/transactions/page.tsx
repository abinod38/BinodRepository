
'use client';

import { Calendar, ChevronDown, History, Search, Trash2, CheckCircle, AlertTriangle, Clock, Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { DatePicker } from "@/components/ui/date-picker";
import { useState, useMemo, useEffect, FC } from "react";
import { useUser, useFirestore, useCollection, useMemoFirebase, updateDocumentNonBlocking, deleteDocumentNonBlocking, useDoc } from '@/firebase';
import { collection, query, orderBy, Timestamp, doc } from 'firebase/firestore';
import { format as formatDateFns, parseISO, isValid, parse } from 'date-fns';
import { Skeleton } from "@/components/ui/skeleton";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/hooks/use-toast";
import Image from 'next/image';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";


const TransactionStatus: FC<{ transaction: any }> = ({ transaction }) => {
  if (transaction.returnedFromBank) {
    return (
      <Badge variant="destructive">
        <AlertTriangle className="mr-1 h-3 w-3" />
        Returned
      </Badge>
    );
  }
  if (transaction.bankDeposited) {
    return (
      <Badge variant="outline" className="font-normal text-green-600 border-green-600/30 bg-green-500/10">
        <CheckCircle className="mr-1 h-3 w-3" />
        Deposited
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="font-normal text-muted-foreground">
      <Clock className="mr-1 h-3 w-3" />
      Waiting Deposit
    </Badge>
  );
};


export default function TransactionsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [date, setDate] = useState<Date | undefined>();
  const [transactionToDelete, setTransactionToDelete] = useState<any | null>(null);
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);
  
  const { toast } = useToast();
  const { user } = useUser();
  const firestore = useFirestore();

  const userDocRef = useMemoFirebase(() => {
    if (!user) return null;
    return doc(firestore, `users/${user.uid}`);
  }, [user, firestore]);
  
  const { data: userData } = useDoc<any>(userDocRef);
  const CORRECT_PIN = userData?.pin || '1234';

  useEffect(() => {
    // Reset PIN when the dialog is closed or a new item is selected
    if (!transactionToDelete) {
      setPin('');
      setPinError(null);
    }
  }, [transactionToDelete]);

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<any>(transactionsQuery);
  
  const filteredTransactions = useMemo(() => {
    if (!transactions) return [];
    
    const lowercasedQuery = searchQuery.toLowerCase();
    const selectedDate = date ? formatDateFns(date, 'yyyy-MM-dd') : null;

    return transactions.filter(transaction => {
      const transactionDate = transaction.createdAt?.toDate ? formatDateFns(transaction.createdAt.toDate(), 'yyyy-MM-dd') : '';
      
      let dateOfTransaction = '';
      if (transaction.dateOfTransaction && typeof transaction.dateOfTransaction === 'string') {
          const parsedDate = parseISO(transaction.dateOfTransaction);
          if(isValid(parsedDate)) {
            dateOfTransaction = formatDateFns(parsedDate, 'yyyy-MM-dd');
          } else {
             const parsedFromOtherFormat = parse(transaction.dateOfTransaction, 'MM-dd-yyyy', new Date());
             if(isValid(parsedFromOtherFormat)) {
                dateOfTransaction = formatDateFns(parsedFromOtherFormat, 'yyyy-MM-dd');
             } else {
                const genericParsedDate = new Date(transaction.dateOfTransaction);
                if (isValid(genericParsedDate)) {
                  dateOfTransaction = formatDateFns(genericParsedDate, 'yyyy-MM-dd');
                }
             }
          }
      }

      const matchesQuery = (
        searchQuery === '' ||
        transaction.customerName?.toLowerCase().includes(lowercasedQuery) ||
        transaction.customerPhone?.toLowerCase().includes(lowercasedQuery) ||
        transaction.idNumber?.toLowerCase().includes(lowercasedQuery) ||
        transaction.checkIssuerName?.toLowerCase().includes(lowercasedQuery) ||
        transaction.issuer?.toLowerCase().includes(lowercasedQuery) ||
        String(transaction.checkAmount)?.toLowerCase().includes(lowercasedQuery) ||
        dateOfTransaction.includes(lowercasedQuery) ||
        transaction.customerSsn?.toLowerCase().includes(lowercasedQuery) ||
        transaction.dob?.toLowerCase().includes(lowercasedQuery) ||
        transaction.checkNumber?.toLowerCase().includes(lowercasedQuery)
      );
      
      const matchesDate = !selectedDate || transactionDate === selectedDate;

      return matchesQuery && matchesDate;
    });
  }, [transactions, searchQuery, date]);


  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value || 0);

  const groupedTransactions = useMemo(() => {
    return filteredTransactions?.reduce((acc, transaction) => {
      const transactionDate = transaction.createdAt?.toDate() || new Date();
      const date = formatDateFns(transactionDate, 'yyyy-MM-dd');
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(transaction);
      return acc;
    }, {} as Record<string, any[]>);
  }, [filteredTransactions]);

  const sortedDates = groupedTransactions ? Object.keys(groupedTransactions).sort((a, b) => new Date(b).getTime() - new Date(a).getTime()) : [];

  const handleStatusChange = (transactionId: string, field: 'bankDeposited' | 'returnedFromBank' | 'returnReason', value: boolean | string) => {
    if (!user || !firestore) return;
    const docRef = doc(firestore, `users/${user.uid}/transactions`, transactionId);

    if (field === 'returnedFromBank' && !value) {
      // If unchecking "Returned From Bank", clear the reason as well
      updateDocumentNonBlocking(docRef, { [field]: value, returnReason: null });
    } else {
      updateDocumentNonBlocking(docRef, { [field]: value });
    }
  };
  
  const handleDeleteTransaction = () => {
    if (pin !== CORRECT_PIN) {
      setPinError('Incorrect PIN. Please try again.');
      return;
    }
    
    if (!user || !firestore || !transactionToDelete) return;

    const docRef = doc(firestore, `users/${user.uid}/transactions`, transactionToDelete.id);
    deleteDocumentNonBlocking(docRef);

    toast({
      title: 'Transaction Deleted',
      description: 'The transaction has been successfully deleted.',
      duration: 2000,
      variant: 'success',
    });
    setTransactionToDelete(null);
  };

  const returnReasons = [
    "Not Sufficient Fund",
    "Closed Account",
    "Refer to Maker",
    "Forged",
    "Altered",
    "Duplicate"
  ];
  
  const handlePinInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Allow only numeric input and limit to 4 digits
    if (/^\d*$/.test(value) && value.length <= 4) {
      setPin(value);
      if (pinError) {
        setPinError(null); // Clear error on new input
      }
    }
  };

  const getInitials = (name?: string) => {
    if (!name) return "";
    const names = name.split(' ');
    if (names.length > 1) {
      return `${names[0][0]}${names[names.length - 1][0]}`.toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
  };
  
  const DetailRow = ({ label, value }: { label: string, value: React.ReactNode }) => (
    <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-medium text-sm">{value || 'N/A'}</p>
    </div>
  );
  
  const formatDateFromISO = (isoString: string | undefined) => {
    if (!isoString) return 'N/A';
    const date = parseISO(isoString);
    if (isValid(date)) {
        return formatDateFns(date, 'MMMM do, yyyy');
    }
    return isoString; // Fallback to original string if invalid
  }


  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <History className="h-8 w-8 text-muted-foreground" />
        <div>
          <h1 className="text-2xl font-bold">Transaction History</h1>
          <p className="text-muted-foreground">Your complete check cashing activity.</p>
        </div>
      </div>

      <div className="flex flex-col md:flex-row items-center gap-4">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search by customer name, phone, check amount, etc..." 
            className="pl-10" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-4 w-full md:w-auto">
            <DatePicker date={date} setDate={setDate} placeholder="Filter by Date" />
        </div>
      </div>

      {isLoading ? (
         <div className="space-y-4">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      ) : sortedDates.length > 0 ? (
        sortedDates.map((date, index) => (
          <Card key={index}>
            <CardHeader>
              <CardTitle className="text-lg">{formatDateFns(parseISO(date), 'MMMM do, yyyy')}</CardTitle>
            </CardHeader>
            <CardContent className="divide-y p-0">
              {groupedTransactions && groupedTransactions[date].map((transaction, idx) => (
                <Collapsible key={transaction.id} asChild>
                  <div className="p-0">
                    <div className="p-4 flex items-center gap-4 hover:bg-muted/50 cursor-pointer">
                      <span className="text-muted-foreground w-8">{idx + 1}.</span>
                       <Avatar className="h-9 w-9">
                        <AvatarImage src={transaction.idImage} alt={transaction.customerName} />
                        <AvatarFallback>{getInitials(transaction.customerName)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-semibold">{transaction.customerName}</p>
                        <p className="text-sm text-muted-foreground">from {transaction.issuer}</p>
                      </div>
                      <div className="flex items-center gap-4">
                          <div className="text-right">
                              <p className="font-bold text-lg">{formatCurrency(transaction.checkAmount)}</p>
                              <TransactionStatus transaction={transaction} />
                          </div>
                          <CollapsibleTrigger asChild>
                            <Button variant="ghost" size="icon">
                                <ChevronDown className="h-5 w-5 transition-transform group-data-[state=open]:rotate-180" />
                            </Button>
                          </CollapsibleTrigger>
                      </div>
                    </div>
                    <CollapsibleContent>
                      <div className="bg-muted/30 px-6 py-4 text-sm">
                        <div className="flex justify-between items-start mb-3">
                          <div className="space-y-3">
                             <div className="flex items-center space-x-2">
                              <Checkbox 
                                id={`bank-deposited-${transaction.id}`} 
                                checked={!!transaction.bankDeposited}
                                onCheckedChange={(checked) => handleStatusChange(transaction.id, 'bankDeposited', !!checked)}
                                />
                              <Label htmlFor={`bank-deposited-${transaction.id}`}>Bank Deposited</Label>
                               {transaction.bankDeposited && (
                                <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200">Yes</Badge>
                               )}
                            </div>
                            <div className="flex items-center space-x-2">
                              <Checkbox 
                                id={`returned-from-bank-${transaction.id}`} 
                                checked={!!transaction.returnedFromBank}
                                onCheckedChange={(checked) => handleStatusChange(transaction.id, 'returnedFromBank', !!checked)}
                                />
                              <Label htmlFor={`returned-from-bank-${transaction.id}`}>Returned From Bank</Label>
                            </div>
                            {transaction.returnedFromBank && (
                                <Select
                                  value={transaction.returnReason}
                                  onValueChange={(value) => handleStatusChange(transaction.id, 'returnReason', value)}
                                >
                                  <SelectTrigger className="w-[280px]">
                                    <SelectValue placeholder="Select a reason for return..." />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {returnReasons.map((reason) => (
                                      <SelectItem key={reason} value={reason}>{reason}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              )}
                          </div>
                          <Button variant="destructive" size="icon" onClick={() => setTransactionToDelete(transaction)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>

                        <Separator className="my-3"/>
                        
                         <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                            <div className="space-y-4">
                                <DetailRow label="Transaction Date" value={formatDateFromISO(transaction.dateOfTransaction)} />
                                <DetailRow label="Transaction Time" value={transaction.time} />
                                <DetailRow label="Customer Phone" value={transaction.customerPhone} />
                                <DetailRow label="Customer SSN" value={transaction.customerSsn} />
                                <DetailRow label="Date of Birth" value={transaction.dob} />
                                <DetailRow label="License #" value={transaction.idNumber} />
                            </div>
                             <div className="space-y-4">
                                <DetailRow label="Check Issuer" value={transaction.checkIssuerName} />
                                <DetailRow label="Issuer Address" value={transaction.checkIssuerAddress} />
                                <DetailRow label="Check #" value={transaction.checkNumber} />
                                <DetailRow label="Bank Name" value={transaction.bankName} />
                                <DetailRow label="Routing #" value={transaction.routingNumber} />
                                <DetailRow label="Account #" value={transaction.accountNumber} />
                            </div>
                        </div>
                        
                        <Separator className="my-3"/>

                        <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                            <DetailRow label="Fee" value={formatCurrency(transaction.fee)} />
                            <DetailRow label="Net Amount" value={formatCurrency(transaction.checkAmount - transaction.fee)} />
                        </div>


                        {transaction.comment && (
                          <>
                            <Separator className="my-3"/>
                            <DetailRow label="Comment" value={transaction.comment} />
                          </>
                        )}
                        
                        {(transaction.checkImage || transaction.idImage) && <Separator className="my-3"/>}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {transaction.checkImage && (
                            <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200">
                              <p className="font-semibold text-emerald-800 mb-2">Check Image</p>
                              <div className="relative aspect-video">
                                <Image src={transaction.checkImage} alt="Check Image" layout="fill" className="rounded-md object-cover"/>
                              </div>
                            </div>
                          )}
                           {transaction.idImage && (
                            <div className="p-4 rounded-lg bg-emerald-50 border border-emerald-200">
                              <p className="font-semibold text-emerald-800 mb-2">ID Image</p>
                              <div className="relative aspect-video">
                                <Image src={transaction.idImage} alt="ID Image" layout="fill" className="rounded-md object-cover"/>
                              </div>
                            </div>
                           )}
                        </div>

                      </div>
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              ))}
            </CardContent>
          </Card>
        ))
      ) : (
        <Card>
          <CardContent className="py-10 text-center">
            <p className="text-muted-foreground">
              {searchQuery ? `No transactions found for "${searchQuery}".` : 'No transaction history found.'}
            </p>
            {!searchQuery && <p className="text-sm text-muted-foreground">Complete a new transaction to see it here.</p>}
          </CardContent>
        </Card>
      )}

      <AlertDialog open={!!transactionToDelete} onOpenChange={(open) => !open && setTransactionToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the transaction for{' '}
              <span className="font-semibold">{transactionToDelete?.customerName}</span> of{' '}
              <span className="font-semibold">{formatCurrency(transactionToDelete?.checkAmount)}</span>.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2">
            <Label htmlFor="pin">Enter your 4-digit PIN to confirm:</Label>
            <Input
              id="pin"
              type="password"
              maxLength={4}
              value={pin}
              onChange={handlePinInputChange}
              className="text-center tracking-[0.5em]"
              placeholder="••••"
            />
            {pinError && <p className="text-sm font-medium text-destructive">{pinError}</p>}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setTransactionToDelete(null)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteTransaction} disabled={pin.length !== 4}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

