

export type Transaction = {
  id: string;
  date: string;
  customerName: string;
  issuer: string;
  amount: number;
  status: 'Completed' | 'Pending' | 'Failed';
  type: 'Income' | 'Expense';
  category: string;
};

export type Check = {
  id: string;
  checkNumber: string;
  payee: string;
  checkIssuer: string;
  amount: number;
  date: string;
  reason: string;
  status: 'On Hold' | 'Returned' | 'Paid' | 'DA Prosecution';
  remarks?: string;
};

export type ReportTransaction = {
  id: string;
  time: string;
  customerName: string;
  checkNumber: string;
  issuer: string;
  amount: number;
  fee: number;
  deposited: 'Yes' | 'No';
  date: string;
};

export type Customer = {
  id: string;
  name: string;
  avatar: string;
  lastSeen: string;
  totalVolume: number;
  goodChecks: number;
  badChecks: number;
};

export type TopEntity = {
  id: string;
  name: string;
  checks: number;
  volume: number;
  fees: number;
  bad: number;
};

export type Vendor = {
  id: string;
  sNo: number;
  name: string;
  salesRep: string;
  salesRepPhone: string;
  deliveryPerson: string;
  deliveryPersonPhone: string;
  deliveryDay: string;
};


export const transactions: Transaction[] = [
  { id: 'TXN1001', date: '2025-11-03T10:00:00.000Z', customerName: "Ronald Halsey", issuer: "World Finance Corporation", amount: 186.01, status: 'Completed', type: 'Income', category: 'Check Cashing' },
  { id: 'TXN1002', date: '2025-11-03T11:30:00.000Z', customerName: "Cody Smith", issuer: "Dura-mar Of Granbury", amount: 250.00, status: 'Completed', type: 'Income', category: 'Check Cashing' },
  { id: 'TXN1003', date: '2025-11-03T14:15:00.000Z', customerName: "Florentino Olviedo", issuer: "Hathaway Property Management", amount: 60.00, status: 'Completed', type: 'Income', category: 'Check Cashing' },
  { id: 'TXN1004', date: '2025-11-02T09:00:00.000Z', customerName: "Destinee June Yvonne Wise", issuer: "David Dulcie Holding Llc & Dba 3b Beers, Brats, And Burgers", amount: 148.00, status: 'Completed', type: 'Income', category: 'Check Cashing' },
  { id: 'TXN1005', date: '2025-11-02T16:45:00.000Z', customerName: "Victor Isait Hernández", issuer: "Banuelos Performance Horses Lic", amount: 1400.00, status: 'Completed', type: 'Income', category: 'Check Cashing' },
  { id: 'TXN1006', date: '2025-11-02T13:00:00.000Z', customerName: "Sandra Ardon Battelana", issuer: "Rio Brazos Grill Lic", amount: 467.52, status: 'Completed', type: 'Income', category: 'Check Cashing' },
  { id: 'TXN1007', date: '2025-11-02T10:20:00.000Z', customerName: "Theron Lemon", issuer: "Kevin Downing & Clarie Downing", amount: 250.00, status: 'Completed', type: 'Income', category: 'Check Cashing' },
  { id: 'TXN1008', date: '2025-11-02T18:00:00.000Z', customerName: "Rigo T. Landscaping", issuer: "Leroy Watson", amount: 2800.00, status: 'Completed', type: 'Income', category: 'Check Cashing' },
  { id: 'TXN1009', date: '2025-11-02T18:05:00.000Z', customerName: "Rigo T. Landscaping", issuer: "Jeffery Griffin", amount: 1100.00, status: 'Completed', type: 'Income', category: 'Check Cashing' },
];

export const onHoldChecks: Check[] = [
  { id: 'CHK501', checkNumber: '345123', payee: 'Global Supplies Inc.', checkIssuer: 'Corporate Solutions', amount: 4500, date: '2023-10-22T10:00:00.000Z', reason: 'Awaiting invoice verification', status: 'On Hold' },
  { id: 'CHK502', checkNumber: '345124', payee: 'Tech Solutions LLC', checkIssuer: 'Venture Capital Group', amount: 12800, date: '2023-10-19T11:00:00.0Z', reason: 'Large amount, requires manager approval', status: 'On Hold' },
  { id: 'CHK503', checkNumber: '345125', payee: 'Creative Marketing Co.', checkIssuer: 'Startup Hub', amount: 2300, date: '2023-10-15T14:30:00.000Z', reason: 'Pending confirmation of service delivery', status: 'On Hold' },
];

export const returnedChecks: Check[] = [
  { id: 'CHK601', checkNumber: '102345', payee: 'John Anderson', checkIssuer: 'Personal Account', amount: 530, date: '2023-10-12T09:00:00.000Z', reason: 'Insufficient funds', status: 'Returned', remarks: 'Second occurrence' },
  { id: 'CHK602', checkNumber: '102349', payee: 'Sarah Connor', checkIssuer: 'Business Account', amount: 120, date: '2023-10-05T15:00:00.000Z', reason: 'Account closed', status: 'Returned', remarks: 'Contacted payee' },
  { id: 'CHK603', checkNumber: '102355', payee: 'Property Management Group', checkIssuer: 'Estate Account', amount: 1800, date: '2023-09-27T10:00:00.000Z', reason: 'Signature mismatch', status: 'Returned', remarks: 'Verification required' },
];

export const daProsecutionChecks: Check[] = [
  { id: 'CHK801', checkNumber: '102345', payee: 'John Anderson', checkIssuer: 'Personal Account', amount: 530, date: '2023-10-12T09:00:00.000Z', reason: 'Submitted to DA', status: 'DA Prosecution', remarks: 'Case #DA-2023-1' },
  { id: 'CHK802', checkNumber: '102349', payee: 'Sarah Connor', checkIssuer: 'Business Account', amount: 120, date: '2023-10-05T15:00:00.000Z', reason: 'Awaiting DA decision', status: 'DA Prosecution', remarks: 'Case #DA-2023-2' },
];


export const paidChecks: Check[] = [
    { id: 'CHK701', checkNumber: '203456', payee: 'Innovate Inc.', checkIssuer: 'Venture Capital Group', amount: 7500, date: '2023-10-20T09:00:00.000Z', reason: 'Payment Cleared', status: 'Paid', remarks: 'Early payment' },
    { id: 'CHK702', checkNumber: '203457', payee: 'Core Services', checkIssuer: 'Corporate Solutions', amount: 250, date: '2023-10-18T14:00:00.000Z', reason: 'Payment Cleared', status: 'Paid' },
    { id: 'CHK703', checkNumber: '203458', payee: 'Office Essentials', checkIssuer: 'Startup Hub', amount: 300, date: '2023-10-15T16:00:00.000Z', reason: 'Payment Cleared', status: 'Paid' },
];

export const reportTransactions: ReportTransaction[] = [
  { id: 'RPT001', time: '8:11 AM', customerName: 'Cody Smith', checkNumber: '19116', issuer: 'Dura-Mar Of Granbury', amount: 250.00, fee: 5.00, deposited: 'No', date: '2025-11-03' },
  { id: 'RPT002', time: '8:11 AM', customerName: 'Florentino Olviedo', checkNumber: '1428', issuer: 'Hathaway Property Management', amount: 60.00, fee: 2.00, deposited: 'No', date: '2025-11-03' },
  { id: 'RPT003', time: '11:51 AM', customerName: 'Ronald Halsey', checkNumber: '0489', issuer: 'World Finance Corporation', amount: 186.01, fee: 4.01, deposited: 'No', date: '2025-11-03' },
  { id: 'RPT004', time: '9:06 AM', customerName: 'Alicia Marie Gandy', checkNumber: '5060157', issuer: 'Kroger', amount: 750.00, fee: 15.00, deposited: 'No', date: '2025-11-02' },
  { id: 'RPT005', time: '8:45 AM', customerName: 'Angie Leon', checkNumber: '004345', issuer: 'New Wave Auto Spa Lic', amount: 118.82, fee: 3.82, deposited: 'No', date: '2025-11-02' },
  { id: 'RPT006', time: '11:57 AM', customerName: 'Brittany Ann Gammons', checkNumber: '283', issuer: 'The Church Of Jesus Christ Of Latter-Day Saints', amount: 120.00, fee: 3.00, deposited: 'No', date: '2025-11-02' },
];

export const customers: Customer[] = [
  { id: 'CUST001', name: 'A&m Concrete', avatar: '', lastSeen: 'October 11th, 2025', totalVolume: 610.00, goodChecks: 1, badChecks: 0 },
  { id: 'CUST002', name: 'Adan M. Hemandez Ardon', avatar: '', lastSeen: 'October 3rd, 2025', totalVolume: 1292.90, goodChecks: 1, badChecks: 0 },
  { id: 'CUST003', name: 'Adan M. Hernandez Ardon', avatar: '', lastSeen: 'October 20th, 2025', totalVolume: 1292.90, goodChecks: 1, badChecks: 0 },
  { id: 'CUST004', name: 'Afria Minor', avatar: '', lastSeen: 'September 20th, 2025', totalVolume: 600.00, goodChecks: 1, badChecks: 0 },
  { id: 'CUST005', name: 'Aiden D Sampson', avatar: '', lastSeen: 'October 31st, 2025', totalVolume: 378.62, goodChecks: 4, badChecks: 0 },
  { id: 'CUST006', name: 'Aiden James Gilbert', avatar: 'https://picsum.photos/seed/6/40/40', lastSeen: 'October 23rd, 2025', totalVolume: 130.91, goodChecks: 1, badChecks: 0 },
  { id: 'CUST007', name: 'Alaunto Garza', avatar: '', lastSeen: 'October 28th, 2025', totalVolume: 442.00, goodChecks: 1, badChecks: 0 },
];

export const dashboardStats = {
  totalBalance: 89543.21,
  incomeThisMonth: 12450.00,
  expensesThisMonth: 4890.50,
  checksOnHold: onHoldChecks.length,
};

export const monthlySpending = [
  { month: 'Oct 5', spending: 10000 },
  { month: 'Oct 7', spending: 12000 },
  { month: 'Oct 9', spending: 65000 },
  { month: 'Oct 11', spending: 22000 },
  { month: 'Oct 13', spending: 25000 },
  { month: 'Oct 15', spending: 35000 },
  { month: 'Oct 17', spending: 50000 },
  { month: 'Oct 19', spending: 31000 },
  { month: 'Oct 21', spending: 21000 },
  { month: 'Oct 24', spending: 82000 },
  { month: 'Oct 27', spending: 22000 },
  { month: 'Oct 30', spending: 14437.25 },
  { month: 'Nov 1', spending: 28000 },
  { month: 'Nov 3', spending: 18000 },
];

export const topCustomers: TopEntity[] = [
  { id: 'CUST001', name: 'Rigo T. Landscaping', checks: 3, volume: 9150.00, fees: 183.00, bad: 0 },
  { id: 'CUST002', name: 'Gerardo Mejia', checks: 2, volume: 7200.00, fees: 72.00, bad: 0 },
  { id: 'CUST003', name: 'Berto\'s Moving', checks: 5, volume: 7100.00, fees: 142.00, bad: 0 },
  { id: 'CUST004', name: 'Javier Valle Espinosa', checks: 2, volume: 3800.00, fees: 76.00, bad: 0 },
  { id: 'CUST005', name: 'Jose Luis Rodriguez', checks: 1, volume: 2250.00, fees: 45.00, bad: 0 },
  { id: 'CUST006', name: 'Noe Rodriquez', checks: 1, volume: 2137.50, fees: 43.50, bad: 0 },
  { id: 'CUST007', name: 'Dylan Chance Walton', checks: 1, volume: 2000.00, fees: 40.00, bad: 0 },
  { id: 'CUST008', name: 'Vicente Hernandez', checks: 2, volume: 1800.00, fees: 36.00, bad: 0 },
  { id: 'CUST009', name: 'Gustavo Jaramillo', checks: 1, volume: 1500.00, fees: 30.00, bad: 0 },
  { id: 'CUST010', name: 'Victor Isait Hernández', checks: 1, volume: 1400.00, fees: 28.00, bad: 0 },
];

export const topIssuers: TopEntity[] = [
  { id: 'ISS001', name: 'Banuelos Performance Horses Lic', checks: 5, volume: 6400.00, fees: 128.00, bad: 0 },
  { id: 'ISS002', name: 'Amy D. Hinze', checks: 1, volume: 5250.00, fees: 105.00, bad: 0 },
  { id: 'ISS003', name: 'Feather Concrete Lic', checks: 1, volume: 5200.00, fees: 52.00, bad: 0 },
  { id: 'ISS004', name: 'Texas Elite Concrete & Construction Lic', checks: 2, volume: 4387.50, fees: 88.50, bad: 0 },
  { id: 'ISS005', name: 'Fleming Signature Homes Lic', checks: 2, volume: 3800.00, fees: 76.00, bad: 0 },
  { id: 'ISS006', name: 'Richard Bailey Jr & Marlowe A Bailey', checks: 1, volume: 3000.00, fees: 60.00, bad: 0 },
  { id: 'ISS007', name: 'Professional Drilling Consultant\'s Lic.', checks: 1, volume: 2900.00, fees: 58.00, bad: 0 },
  { id: 'ISS008', name: 'Leroy Watson', checks: 1, volume: 2800.00, fees: 56.00, bad: 0 },
  { id: 'ISS009', name: 'Mdm Lawn Care Services', checks: 2, volume: 2144.36, fees: 22.36, bad: 0 },
  { id: 'ISS010', name: 'Texas Car Title And Payday Loan Services, Inc.', checks: 1, volume: 2000.00, fees: 40.00, bad: 0 },
];

export const vendors: Vendor[] = [
];
