
'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface CameraCaptureProps {
  onCapture: (imageDataUrl: string) => void;
  captureType?: 'check' | 'id';
}

export function CameraCapture({ onCapture, captureType = 'check' }: CameraCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const guideRef = useRef<HTMLDivElement>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    let stream: MediaStream | null = null;
    const getCameraPermission = async () => {
      try {
        const supportedConstraints = navigator.mediaDevices.getSupportedConstraints();
        const videoConstraints: MediaTrackConstraints = {};
        if (supportedConstraints.facingMode) {
          videoConstraints.facingMode = 'environment';
        }
        
        stream = await navigator.mediaDevices.getUserMedia({ video: videoConstraints });
        setHasCameraPermission(true);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.warn("Could not get environment camera, trying any camera.", err);
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video: true });
          setHasCameraPermission(true);
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        } catch (error) {
            console.error('Error accessing camera:', error);
            setHasCameraPermission(false);
            toast({
              variant: 'destructive',
              title: 'Camera Access Denied',
              description: 'Please enable camera permissions in your browser settings to use this feature.',
            });
        }
      }
    };

    getCameraPermission();

    return () => {
      // Cleanup: stop camera stream when component unmounts
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [toast]);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current && guideRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const guide = guideRef.current;
      const context = canvas.getContext('2d');

      if (context) {
        // Get the intrinsic (actual) dimensions of the video stream
        const videoWidth = video.videoWidth;
        const videoHeight = video.videoHeight;
  
        // Get the display dimensions of the video element
        const videoRect = video.getBoundingClientRect();
  
        // Get the display dimensions of the guide overlay
        const guideRect = guide.getBoundingClientRect();
  
        // Calculate the scale factor between the video's display size and its actual size
        const scaleX = videoWidth / videoRect.width;
        const scaleY = videoHeight / videoRect.height;
  
        // Calculate the crop area in the video's native resolution
        const cropX = (guideRect.left - videoRect.left) * scaleX;
        const cropY = (guideRect.top - videoRect.top) * scaleY;
        const cropWidth = guideRect.width * scaleX;
        const cropHeight = guideRect.height * scaleY;

        // Set the canvas to the size of the cropped area
        canvas.width = cropWidth;
        canvas.height = cropHeight;

        // Draw the cropped portion of the video onto the canvas
        context.drawImage(
          video,
          cropX,
          cropY,
          cropWidth,
          cropHeight,
          0,
          0,
          cropWidth,
          cropHeight
        );

        const dataUrl = canvas.toDataURL('image/jpeg');
        onCapture(dataUrl);
      }
    }
  };
  
  // This is the overlay for the capture guide.
  const CaptureGuideOverlay = () => (
    <div 
      ref={guideRef}
      className={cn(
        "absolute border-[3px] border-dashed border-blue-400 rounded-lg pointer-events-none",
        captureType === 'check' ? "inset-x-[1%] inset-y-[14%]" : "inset-x-[8%] inset-y-4"
        )}
      data-comment="This div creates the blue dotted rectangle. It's styled based on captureType."
    />
  );


  return (
    <div className="space-y-4">
      <div className="relative w-full aspect-video border rounded-md overflow-hidden bg-black flex items-center justify-center">
        <video ref={videoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
        {hasCameraPermission && <CaptureGuideOverlay />}
      </div>

      {hasCameraPermission === false && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Camera Access Required</AlertTitle>
          <AlertDescription>
            Please allow camera access in your browser settings to use this feature.
          </AlertDescription>
        </Alert>
      )}

      {hasCameraPermission === true && (
          <Button onClick={handleCapture} className="w-full">
            <Camera className="mr-2 h-4 w-4" />
            Capture Image
          </Button>
      )}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}
