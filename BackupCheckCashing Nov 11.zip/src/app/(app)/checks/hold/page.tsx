import { onHoldChecks } from "@/lib/data";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";

export default function ChecksOnHoldPage() {
  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Checks On Hold / Buyback</CardTitle>
        <CardDescription>
          Monitor and manage checks that are currently on hold or in buyback.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Check #</TableHead>
              <TableHead>Payee</TableHead>
              <TableHead>Reason for Hold</TableHead>
              <TableHead className="text-right">Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {onHoldChecks.map((check) => (
              <TableRow key={check.id}>
                <TableCell>
                  {formatDate(check.date)}
                </TableCell>
                <TableCell>
                  <Badge variant="secondary">{check.checkNumber}</Badge>
                </TableCell>
                <TableCell className="font-medium">{check.payee}</TableCell>
                <TableCell className="text-muted-foreground">{check.reason}</TableCell>
                <TableCell className="text-right font-medium">
                  {formatCurrency(check.amount)}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
