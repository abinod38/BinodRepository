
'use client';

import { useMemo } from 'react';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, Timestamp } from 'firebase/firestore';
import { format as formatDateFns } from 'date-fns';
import { useRouter } from 'next/navigation';
import { MoreHorizontal, Pencil, Trash2 } from 'lucide-react';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from '@/components/ui/skeleton';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Button } from '@/components/ui/button';


export default function ReturnedChecksPage() {
  const { user } = useUser();
  const firestore = useFirestore();
  const router = useRouter();

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<any>(transactionsQuery);

  const returnedChecks = useMemo(() => {
    if (!transactions) return [];
    return transactions.filter(t => t.returnedFromBank);
  }, [transactions]);

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value || 0);

  const formatDate = (timestamp: Timestamp) => {
    if (!timestamp) return 'N/A';
    return formatDateFns(timestamp.toDate(), 'MM/dd/yyyy');
  }

  const handleRowClick = (id: string) => {
    router.push(`/checks/returned/${id}`);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Returned Checks</CardTitle>
        <CardDescription>
          Track and manage all returned checks from your transaction history.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Check #</TableHead>
              <TableHead>Payee</TableHead>
              <TableHead>Check Issuer</TableHead>
              <TableHead>Reason for Return</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead className="text-right">Actions</TableHead>
              <TableHead>Remarks</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell colSpan={8}>
                    <Skeleton className="h-10 w-full" />
                  </TableCell>
                </TableRow>
              ))
            ) : returnedChecks.length > 0 ? (
                returnedChecks.map((check) => (
                <TableRow key={check.id} >
                  <TableCell onClick={() => handleRowClick(check.id)} className="cursor-pointer">
                    {formatDate(check.createdAt)}
                  </TableCell>
                  <TableCell onClick={() => handleRowClick(check.id)} className="cursor-pointer">
                    <Badge variant="secondary">{check.checkNumber}</Badge>
                  </TableCell>
                  <TableCell onClick={() => handleRowClick(check.id)} className="font-medium cursor-pointer">{check.customerName}</TableCell>
                  <TableCell onClick={() => handleRowClick(check.id)} className="cursor-pointer">{check.issuer}</TableCell>
                  <TableCell onClick={() => handleRowClick(check.id)} className="cursor-pointer">
                    <Badge variant="destructive">{check.returnReason || 'Returned'}</Badge>
                  </TableCell>
                  <TableCell onClick={() => handleRowClick(check.id)} className="text-right font-medium cursor-pointer">
                    {formatCurrency(check.checkAmount)}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem onClick={() => handleRowClick(check.id)}>
                                <Pencil className="mr-2 h-4 w-4" />
                                View/Edit Details
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                  <TableCell onClick={() => handleRowClick(check.id)} className="text-muted-foreground cursor-pointer">{check.comment}</TableCell>
                </TableRow>
              ))
            ) : (
                <TableRow>
                    <TableCell colSpan={8} className="h-24 text-center">
                        No returned checks found.
                    </TableCell>
                </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
