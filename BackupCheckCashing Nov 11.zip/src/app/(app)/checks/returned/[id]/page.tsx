'use client';

import { useMemo, useState } from 'react';
import { useUser, useFirestore, useDoc, useMemoFirebase, updateDocumentNonBlocking } from '@/firebase';
import { doc, Timestamp } from 'firebase/firestore';
import { format as formatDateFns } from 'date-fns';
import { ArrowLeft, User, Building, Calendar, Hash, CircleDollarSign, AlertTriangle, MessageSquare, Landmark, CreditCard, Phone, Lock, Gavel, CheckCircle, ChevronDown } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useToast } from '@/hooks/use-toast';

export default function ReturnedCheckDetailPage({ params }: { params: { id: string } }) {
  const { user } = useUser();
  const firestore = useFirestore();
  const { toast } = useToast();

  const transactionDocRef = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return doc(firestore, `users/${user.uid}/transactions`, params.id);
  }, [user, firestore, params.id]);

  const { data: transaction, isLoading } = useDoc<any>(transactionDocRef);

  const handleDaStatusChange = (status: 'Submitted' | 'Recalled' | null) => {
    if (!transactionDocRef) return;
    
    updateDocumentNonBlocking(transactionDocRef, { daStatus: status });

    toast({
      title: "Status Updated",
      description: `Check has been marked as '${status}'.`,
      variant: 'success'
    });
  };

  const handlePaymentStatusChange = (status: string | null) => {
    if (!transactionDocRef) return;

    let updateData: { bankDeposited: boolean, paymentMethod: string | null };

    if (status === null) {
      // This is for 'Undo Payment'
      updateData = { bankDeposited: false, paymentMethod: null };
    } else {
      updateData = { bankDeposited: true, paymentMethod: status };
    }
    
    updateDocumentNonBlocking(transactionDocRef, updateData);

    toast({
      title: "Payment Status Updated",
      description: status ? `Check marked as paid via ${status}.` : "Payment status has been reset.",
      variant: 'success'
    });
  };

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(value || 0);

  const formatDate = (timestamp: Timestamp) => {
    if (!timestamp) return 'N/A';
    return formatDateFns(timestamp.toDate(), 'MMMM do, yyyy');
  }

  const DetailRow = ({ icon: Icon, label, value }: { icon: React.ElementType, label: string, value: React.ReactNode }) => (
    <div className="flex items-start gap-3">
      <Icon className="h-5 w-5 text-muted-foreground mt-1 flex-shrink-0" />
      <div className="flex-1">
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="font-medium">{value || 'N/A'}</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
       <div className="flex justify-between items-center">
        <Link href="/checks/returned">
            <Button variant="outline">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Returned Checks
            </Button>
        </Link>
        {transaction && !isLoading && (
            <div className="flex gap-4">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline">
                      <Gavel className="mr-2 h-4 w-4" />
                      DA Prosecution
                      <ChevronDown className="ml-2 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={() => handleDaStatusChange('Submitted')}>Submitted to DA</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleDaStatusChange('Recalled')}>Recalled from DA</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => handleDaStatusChange(null)} className="text-red-600">Clear Status</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button className="bg-green-600 hover:bg-green-700">
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Check Paid
                        <ChevronDown className="ml-2 h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                   <DropdownMenuContent>
                    <DropdownMenuLabel>Payment Status</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => handlePaymentStatusChange('Paid')}>Mark as Paid</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handlePaymentStatusChange('Cash')}>Paid by Cash</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handlePaymentStatusChange('Card')}>Paid by Card</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handlePaymentStatusChange('Check')}>Paid By Check</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handlePaymentStatusChange('Money Order')}>Paid By Money Order</DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handlePaymentStatusChange('Cash & Card')}>Paid Cash & Card</DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem className="text-red-600" onClick={() => handlePaymentStatusChange(null)}>Undo Payment</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
            </div>
        )}
       </div>
    
      <Card>
        <CardHeader>
          {isLoading ? (
            <>
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
            </>
          ) : transaction ? (
            <>
              <CardTitle className="flex items-center justify-between">
                <span>Check from {transaction.issuer}</span>
                <div className='flex gap-2'>
                    {transaction.bankDeposited && <Badge className="bg-green-500 text-white">Paid ({transaction.paymentMethod})</Badge>}
                    {transaction.daStatus && <Badge variant="outline">{transaction.daStatus}</Badge>}
                    <Badge variant="destructive">{transaction.returnReason || 'Returned'}</Badge>
                </div>
              </CardTitle>
              <CardDescription>
                Returned on {formatDate(transaction.createdAt)} for {formatCurrency(transaction.checkAmount)}
              </CardDescription>
            </>
          ) : (
            <CardTitle>Transaction Not Found</CardTitle>
          )}
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-32 w-full" />
            </div>
          ) : transaction ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Payee Information</h3>
                <DetailRow icon={User} label="Customer Name" value={transaction.customerName} />
                <DetailRow icon={Phone} label="Customer Phone" value={transaction.customerPhone} />
                <DetailRow icon={CreditCard} label="License #" value={transaction.idNumber} />
                <DetailRow icon={Lock} label="SSN" value={transaction.customerSsn} />
                <DetailRow icon={Calendar} label="Date of Birth" value={transaction.dob} />
              </div>
              <div className="space-y-4">
                <h3 className="font-semibold text-lg">Check Details</h3>
                <DetailRow icon={Building} label="Check Issuer" value={transaction.issuer} />
                <DetailRow icon={Hash} label="Check #" value={transaction.checkNumber} />
                <DetailRow icon={CircleDollarSign} label="Amount" value={formatCurrency(transaction.checkAmount)} />
                <DetailRow icon={AlertTriangle} label="Reason for Return" value={transaction.returnReason} />
                <DetailRow icon={Landmark} label="Bank Name" value={transaction.bankName} />
              </div>
              {transaction.comment && (
                 <div className="md:col-span-2 space-y-4">
                    <Separator />
                    <DetailRow icon={MessageSquare} label="Comment" value={transaction.comment} />
                 </div>
              )}
               {(transaction.checkImage || transaction.idImage) && (
                 <div className="md:col-span-2 space-y-4">
                    <Separator />
                    <h3 className="font-semibold text-lg">Captured Images</h3>
                    <div className="flex gap-4">
                        {transaction.checkImage && <Image src={transaction.checkImage} alt="Check Image" width={200} height={100} className="rounded-lg object-cover" />}
                        {transaction.idImage && <Image src={transaction.idImage} alt="ID Image" width={200} height={125} className="rounded-lg object-cover" />}
                    </div>
                 </div>
               )}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-muted-foreground">The requested transaction could not be found.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
