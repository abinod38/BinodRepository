
'use client';

import { useState, useMemo } from 'react';
import {
  Users,
  Building,
  Search,
  ChevronRight,
  BarChart,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, Timestamp } from 'firebase/firestore';
import { Skeleton } from '@/components/ui/skeleton';
import { format as formatDateFns } from 'date-fns';

type AggregatedCustomer = {
  name: string;
  avatar: string;
  firstSeen: string;
  lastSeen: string;
  totalVolume: number;
  goodChecks: number;
  badChecks: number; // Assuming all for now are good
};

export default function CustomersPage() {
  const [activeTab, setActiveTab] = useState('customers');

  const { user } = useUser();
  const firestore = useFirestore();

  const transactionsQuery = useMemoFirebase(() => {
    if (!user || !firestore) return null;
    return query(
      collection(firestore, `users/${user.uid}/transactions`),
      orderBy('createdAt', 'desc')
    );
  }, [user, firestore]);

  const { data: transactions, isLoading } = useCollection<any>(transactionsQuery);

  const aggregatedCustomers = useMemo(() => {
    if (!transactions) return [];

    const customerData: Record<string, {
      name: string;
      totalVolume: number;
      checkCount: number;
      dates: Date[];
    }> = {};

    transactions.forEach(t => {
      if (!t.customerName) return;

      if (!customerData[t.customerName]) {
        customerData[t.customerName] = {
          name: t.customerName,
          totalVolume: 0,
          checkCount: 0,
          dates: [],
        };
      }
      customerData[t.customerName].totalVolume += t.checkAmount || 0;
      customerData[t.customerName].checkCount += 1;
      if (t.createdAt) {
        customerData[t.customerName].dates.push((t.createdAt as Timestamp).toDate());
      }
    });

    return Object.values(customerData).map(cust => {
      const sortedDates = cust.dates.sort((a, b) => b.getTime() - a.getTime());
      const lastSeen = sortedDates.length > 0 ? formatDateFns(sortedDates[0], 'MMMM do, yyyy') : 'N/A';
      const firstSeen = sortedDates.length > 0 ? formatDateFns(sortedDates[sortedDates.length - 1], 'MMMM do, yyyy') : 'N/A';
      
      return {
        name: cust.name,
        avatar: '', // Placeholder avatar
        firstSeen: firstSeen,
        lastSeen: lastSeen,
        totalVolume: cust.totalVolume,
        goodChecks: cust.checkCount,
        badChecks: 0, // Placeholder
      };
    }).sort((a, b) => {
      if (a.lastSeen === 'N/A') return 1;
      if (b.lastSeen === 'N/A') return -1;
      return new Date(b.lastSeen).getTime() - new Date(a.lastSeen).getTime()
    });

  }, [transactions]);

  const formatCurrency = (value: number) =>
    new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
      <TabsList className="grid w-full grid-cols-2 max-w-sm">
          <TabsTrigger value="customers">
            <Users className="mr-2 h-4 w-4" />
            Customers
          </TabsTrigger>
          <TabsTrigger value="check-issuers">
            <Building className="mr-2 h-4 w-4" />
            Check Issuers
          </TabsTrigger>
        </TabsList>
        <TabsContent value="customers">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
                <div>
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <Users className="text-muted-foreground" /> All Customers
                  </h2>
                  <p className="text-muted-foreground">
                    A list of all customers in your system.
                  </p>
                </div>
                <div className="relative w-full md:w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search by name..." className="pl-10" />
                </div>
              </div>

              <div className="flex items-center gap-2 mb-4">
                <span className="text-sm font-medium">Filters:</span>
                <Button variant="secondary" size="sm" className="bg-teal-600/20 text-teal-500">
                  All
                </Button>
                <Button variant="outline" size="sm">
                  Inactive &gt;15 days
                </Button>
                <Button variant="outline" size="sm">
                  Inactive &gt;30 days
                </Button>
              </div>

              <div className="space-y-4">
                {isLoading ? (
                  <>
                    <Skeleton className="h-24 w-full" />
                    <Skeleton className="h-24 w-full" />
                    <Skeleton className="h-24 w-full" />
                  </>
                ) : aggregatedCustomers.length > 0 ? (
                  aggregatedCustomers.map((customer, index) => (
                  <Card key={customer.name} className="p-4 flex items-center justify-between hover:bg-muted/50">
                    <div className="flex items-center gap-4 flex-1 min-w-0">
                      <span className="text-muted-foreground w-6 text-center">{index + 1}.</span>
                      <Avatar>
                        <AvatarImage src={customer.avatar} />
                        <AvatarFallback>{customer.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="truncate">
                        <p className="font-semibold truncate">{customer.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Last seen: {customer.lastSeen}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          First seen: {customer.firstSeen}
                        </p>
                      </div>
                    </div>
                    <div className="hidden sm:flex items-center gap-6">
                      <div className="text-right w-32">
                        <p className="font-bold">{formatCurrency(customer.totalVolume)}</p>
                        <p className="text-xs text-muted-foreground flex items-center justify-end gap-1">
                          <BarChart className="h-3 w-3" /> Total Volume
                        </p>
                      </div>
                      <div className="text-right w-28">
                        <p className="font-bold flex items-center justify-end gap-1 text-green-500">
                          <CheckCircle className="h-4 w-4" /> {customer.goodChecks}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Good Checks
                        </p>
                      </div>
                      <div className="text-right w-28">
                        <p className="font-bold flex items-center justify-end gap-1 text-red-500">
                          <AlertTriangle className="h-4 w-4" /> {customer.badChecks}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Bad Checks
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="text-muted-foreground ml-4" />
                  </Card>
                ))
              ) : (
                <div className="text-center py-10">
                  <p className="text-muted-foreground">No customers found.</p>
                </div>
              )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="check-issuers">
          <Card>
            <CardContent className="pt-6">
              <p>Check Issuers will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
