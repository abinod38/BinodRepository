'use client';

import { useState, useRef, useEffect } from 'react';
import { useUser, useFirestore, useCollection, useMemoFirebase, useStorage } from '@/firebase';
import { collection, query, orderBy, doc } from 'firebase/firestore';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { PlusCircle, Edit, Trash2, CheckCircle, AlertCircle } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import Image from 'next/image';
import { differenceInDays, parseISO, format, isValid } from 'date-fns';

import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from '@/components/ui/skeleton';
import { useToast } from '@/hooks/use-toast';
import { addDocumentNonBlocking, deleteDocumentNonBlocking, setDocumentNonBlocking } from '@/firebase/non-blocking-updates';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { ManualDatePicker } from '@/components/ui/manual-date-picker';

const licenseFormSchema = z.object({
  name: z.string().min(1, 'License name is required'),
  type: z.string().optional(),
  issueDate: z.date({ required_error: "Issue date is required." }),
  expiryDate: z.date({ required_error: "Expiry date is required." }),
  imageUrl: z.string().optional(),
});

type LicenseFormValues = z.infer<typeof licenseFormSchema>;

type License = Omit<LicenseFormValues, 'issueDate' | 'expiryDate'> & {
  id: string;
  issueDate: { seconds: number; nanoseconds: number; } | string;
  expiryDate: { seconds: number; nanoseconds: number; } | string;
};


export default function LicensesPage() {
  const { toast } = useToast();
  const { user } = useUser();
  const firestore = useFirestore();
  const storage = useStorage();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [licenseToDelete, setLicenseToDelete] = useState<License | null>(null);
  const [editingLicense, setEditingLicense] = useState<License | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const licensesQuery = useMemoFirebase(() => {
    if (!user) return null;
    return query(
      collection(firestore, `users/${user.uid}/licenses`),
      orderBy('expiryDate')
    );
  }, [user, firestore]);

  const { data: licenses, isLoading } = useCollection<License>(licensesQuery);
  
  const form = useForm<LicenseFormValues>({
    resolver: zodResolver(licenseFormSchema),
    defaultValues: {
      name: '',
      type: '',
      imageUrl: '',
    },
  });

  const handleDialogOpen = (license: License | null = null) => {
    setEditingLicense(license);
    setSelectedFile(null);
    if (license) {
      let issueDate, expiryDate;
      if (license.issueDate) {
        const d = typeof license.issueDate === 'string' ? new Date(license.issueDate) : new Date(license.issueDate.seconds * 1000);
        if (isValid(d)) issueDate = d;
      }
       if (license.expiryDate) {
        const d = typeof license.expiryDate === 'string' ? new Date(license.expiryDate) : new Date(license.expiryDate.seconds * 1000);
        if (isValid(d)) expiryDate = d;
      }
      form.reset({
        ...license,
        issueDate: issueDate,
        expiryDate: expiryDate,
      });
    } else {
      form.reset({
        name: '',
        type: '',
        issueDate: undefined,
        expiryDate: undefined,
        imageUrl: '',
      });
    }
    setIsDialogOpen(true);
  };
  
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const onSubmit = async (data: LicenseFormValues) => {
    if (!user) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'You must be logged in to manage licenses.',
      });
      return;
    }
    
    setIsUploading(true);

    let imageUrl = editingLicense?.imageUrl || '';

    if (selectedFile) {
      const imageRef = storageRef(storage, `licenses/${user.uid}/${selectedFile.name}`);
      try {
        const snapshot = await uploadBytes(imageRef, selectedFile);
        imageUrl = await getDownloadURL(snapshot.ref);
      } catch (error) {
        toast({
          variant: 'destructive',
          title: 'Upload Failed',
          description: 'There was an error uploading the license image.',
        });
        setIsUploading(false);
        return;
      }
    }

    const licenseData = { ...data, imageUrl, issueDate: data.issueDate.toISOString(), expiryDate: data.expiryDate.toISOString() };

    if (editingLicense) {
      const docRef = doc(firestore, `users/${user.uid}/licenses`, editingLicense.id);
      setDocumentNonBlocking(docRef, licenseData, { merge: true });
      toast({
        title: 'License Updated',
        description: `${data.name} has been successfully updated.`,
      });
    } else {
      const licensesColRef = collection(firestore, `users/${user.uid}/licenses`);
      addDocumentNonBlocking(licensesColRef, licenseData);
      toast({
        title: 'License Added',
        description: `${data.name} has been successfully added.`,
      });
    }

    setIsUploading(false);
    form.reset();
    setIsDialogOpen(false);
    setEditingLicense(null);
  };
  
  const handleDeleteLicense = () => {
    if (!user || !licenseToDelete) return;

    const docRef = doc(firestore, `users/${user.uid}/licenses`, licenseToDelete.id);
    deleteDocumentNonBlocking(docRef);

    toast({
      title: "License Deleted",
      description: `The license ${licenseToDelete.name} has been deleted.`,
    });
    setLicenseToDelete(null);
  };

  const getStatus = (expiryDate: License['expiryDate']) => {
    const date = new Date(typeof expiryDate === 'string' ? expiryDate : expiryDate.seconds * 1000);
    if (!isValid(date)) return <Badge variant="secondary">Invalid Date</Badge>;
    const today = new Date();
    today.setHours(0,0,0,0);
    const daysUntilExpiry = differenceInDays(date, today);

    if (daysUntilExpiry < 0) {
      return <Badge variant="destructive">Expired</Badge>;
    }
    if (daysUntilExpiry <= 30) {
      return <Badge variant="destructive" className="bg-red-500 text-white flex items-center gap-1"><AlertCircle className="h-3 w-3" />Expires in {daysUntilExpiry} days</Badge>;
    }
    return <Badge className="bg-green-500 text-white flex items-center gap-1"><CheckCircle className="h-3 w-3" />Active</Badge>;
  };
  
  const formatDate = (date: License['issueDate']) => {
    if (!date) return '';
    const d = new Date(typeof date === 'string' ? date : date.seconds * 1000);
    if (!isValid(d)) return 'Invalid Date';
    return format(d, 'MMMM do, yyyy');
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between md:items-center">
            <div>
                <CardTitle>All Licenses</CardTitle>
                <CardDescription>A list of all your business licenses and their expiration dates.</CardDescription>
            </div>
            <Button onClick={() => handleDialogOpen()}>
                <PlusCircle className="mr-2 h-4 w-4" />
                Add New License
            </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>SN</TableHead>
              <TableHead>License Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Issue Date</TableHead>
              <TableHead>Expiry Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Image</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
             {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <TableRow key={i}>
                    <TableCell colSpan={8}>
                      <Skeleton className="h-10 w-full" />
                    </TableCell>
                  </TableRow>
                ))
              ) : licenses && licenses.length > 0 ? (
                licenses.map((license, index) => (
                  <TableRow key={license.id}>
                    <TableCell>{index + 1}</TableCell>
                    <TableCell className="font-medium">{license.name}</TableCell>
                    <TableCell>{license.type}</TableCell>
                    <TableCell>{formatDate(license.issueDate)}</TableCell>
                    <TableCell>{formatDate(license.expiryDate)}</TableCell>
                    <TableCell>{getStatus(license.expiryDate)}</TableCell>
                    <TableCell>
                      {license.imageUrl && (
                        <Image src={license.imageUrl} alt={license.name} width={40} height={40} className="rounded-md object-cover"/>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => handleDialogOpen(license)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setLicenseToDelete(license)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
             ) : (
                <TableRow>
                  <TableCell colSpan={8} className="h-24 text-center">
                    No licenses found. Add a new license to get started.
                  </TableCell>
                </TableRow>
             )}
          </TableBody>
        </Table>
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{editingLicense ? 'Edit License' : 'Add New License'}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>License Name</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Alarm Permit" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Type</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., City of Granbury" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="issueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Issue Date</FormLabel>
                      <ManualDatePicker date={field.value} setDate={field.onChange} />
                      <FormMessage />
                    </FormItem>
                  )}
                />
                 <FormField
                  control={form.control}
                  name="expiryDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Expiry Date</FormLabel>
                      <ManualDatePicker date={field.value} setDate={field.onChange} />
                       <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormItem>
                <FormLabel>License Image</FormLabel>
                <FormControl>
                  <Input type="file" accept="image/*" ref={fileInputRef} onChange={handleFileChange} />
                </FormControl>
                {selectedFile && <p className="text-sm text-muted-foreground">New file selected: {selectedFile.name}</p>}
                {(form.getValues('imageUrl') && !selectedFile) && <p className="text-sm text-muted-foreground">Current image is saved.</p>}
                <FormMessage />
              </FormItem>
              <DialogFooter>
                <DialogClose asChild>
                  <Button type="button" variant="secondary">Cancel</Button>
                </DialogClose>
                <Button type="submit" disabled={isUploading}>{isUploading ? 'Saving...' : editingLicense ? 'Save Changes' : 'Add License'}</Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
       <AlertDialog open={!!licenseToDelete} onOpenChange={(open) => !open && setLicenseToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the license
              <span className="font-semibold"> {licenseToDelete?.name}</span>.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteLicense}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
