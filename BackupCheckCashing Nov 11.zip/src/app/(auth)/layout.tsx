
"use client"

import { useUser } from "@/firebase/auth/use-user";
import { redirect } from "next/navigation";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { user, isUserLoading } = useUser();

  if (isUserLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p>Loading...</p>
      </div>
    );
  }

  if (user) {
    return redirect("/transactions/new");
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-background">
      {children}
    </div>
  )
}
